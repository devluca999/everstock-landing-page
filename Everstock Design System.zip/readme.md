# Everstock — Product Design System

The design system for the **Everstock product interface**: the live application people work in daily. This is a separate system from the marketing site (tryeverstock.com) and is **not** bound by the site's flat / hairline-only panel rules. The site is a performance; the product is a place you inhabit.

## The company

Everstock is **agentic procurement automation**, built to be **industry- and vertical-agnostic**. The platform architecture assumes no single vertical. The initial wedge covers two starting verticals:

- **Auto parts distribution** — tires, brake pads, rotors, filters, batteries, fluids
- **Electronics distribution** — components, connectors, MCUs, passives

Every example in this system deliberately draws from both, and component names and fixed UI copy stay generic (`DataValue`, `part`, `vendor`, `line`) so a third vertical needs no rework. Nothing in the component API says "tire" or hard-codes SKU semantics.

Marketing-site strapline, for tone reference only: *"Supply-chain intelligence, at your command."* / *"Agentic procurement, deterministic trust."*

## Core philosophy

**The interface should feel like a living environment the user inhabits and works alongside, not software they operate.**

Most B2B and agent software builds trust through density and control surfaces — tables, dashboards, confirmation dialogs. That is a control-room model. Everstock chooses a different trust mechanism: **visible, legible presence.** The user trusts the system because they can see it working, in a form that reads like a real process happening in front of them, and they always know how to interrupt it.

That only works if it never costs time. **"Don't waste people's time" is the load-bearing constraint on the whole system.** Presence has to earn its keep on every screen.

## The five pillars

1. **Material duality as a semantic system.** Frosted glass = active, in-motion, ephemeral. Chrome/metallic = resolved, committed, executed. The glass→chrome transition is a meaningful material event, not decoration.
2. **Colour as strict state language.** Blue = agent working. Amber = needs input. Green = resolved. Red = failure / human required. Hue never doubles as category — category lives in icon, shape or position.
3. **Presence-based interaction.** Center-stage work module (never a spinner or a percentage), a persistent floating input oval, and a bento command hub whose tiles show live content.
4. **A firm line between living and calm.** Where the agent works: full atmosphere. Review and lookup surfaces (quotes, invoices, PO records): fast, dense, scannable, with ambient presence as a garnish only.
5. **Motion as enhancement, never foundation.** Every state must be legible from a single still frame. If reduced motion makes Everstock look like generic SaaS, the differentiation was only ever in the animation.

---

## Sources this system was built from

| Source | Status |
|---|---|
| `uploads/everstock-product-design-system.md` | The durable spec. **Treat it as the continuous reference** — everything here derives from it. |
| Marketing-site screenshots (light + dark hero), supplied in chat | Used for the logo, the beam-field motif and the wordmark. |
| Reference for hub motion: reactbits.dev "Magic Bento" (https://reactbits.dev/components/magic-bento) | Adapted into Everstock's state-colour + beam-particle language, not used as a generic effect. |
| Codebase / Figma | **Not provided.** No product code or Figma file was available, so screens are built from the spec rather than recreated from source. If either exists, attach it — the UI kit should be re-derived from it. |

---

## CONTENT FUNDAMENTALS

**Voice: a competent colleague reporting in, not a product announcing itself.** Everstock states what it did, what it is doing, and what it needs — then stops talking.

- **Person.** The agent is referred to in the third person by name: *"Everstock issues the PO and watches the vendor inbox."* The user is *you*. The product never says *we*, and it never says *I*.
- **Casing.** Sentence case everywhere — headings, buttons, badges, nav, table headers. The single exception is the **micro-label** (`UNIT PRICE`, `LEAD TIME`, `WORKING NOW`), which is small, letter-spaced, muted and used only as a field label. Never uppercase a heading, button or badge.
- **Tense.** Present tense for what is happening (*"Comparing 14 vendor quotes"*, *"Requesting quote 07 of 14"*), past tense for what resolved (*"PO-2291 issued"*, *"Meridian Supply acknowledged in 40 seconds"*).
- **Numbers are always specific.** *"Comparing 14 vendor quotes"*, not *"Comparing quotes"*. *"Acknowledged in 40 seconds"*, not *"Acknowledged quickly"*. Never a percentage of progress — a percentage is exactly the control-room signal this product replaces.
- **Length.** Titles run 3–8 words. Body copy is 1–2 sentences. Nothing on a working surface exceeds three lines.
- **Interrupt language is plain and always available.** *Interrupt*, *Pause*, *Keep comparing*. Never *Cancel operation* or *Abort*.
- **Commitment language is unambiguous.** Anything irreversible says so in the same breath: *"Issuing the order is a committed action and cannot be undone."* Chrome material and this sentence always travel together.
- **No exclamation marks. No emoji. No cheerleading.** No *"Great news!"*, no *"Oops"*, no *"Let's get started"*. When something fails, say what failed and what is needed: *"Vendor reports no stock against this part. Everstock has paused outreach and needs a decision before substituting."*
- **Empty states describe the next real action**, not the absence: *"Nothing needs you right now. Everstock is watching 3 vendor threads."*

Sample copy set, verbatim from the kit:

> Comparing 14 vendor quotes · Brake rotors · 480 units · delivery by 12 Mar
> Evaluating Northline Parts
> Paused — waiting on you
> PO-2291 issued to Meridian Supply · Confirmed 4 seconds ago
> Locked in — this cannot be undone
> Review surfaces stay calm on purpose.

---

## VISUAL FOUNDATIONS

### Colour

- **Dark is the flagship.** Page background is **warm-neutral graphite `#16171B`** — asphalt, not navy. If a render reads "dark blue SaaS app", that is a miss to correct, not a variant to accept. The full ramp runs `--gr-1000` → `--gr-050`.
- **Light mode is a required deliverable on every pass**, not phase two. Background is **warm eggshell `#FAF7F1`** — paper or matte industrial off-white, never `#FFFFFF` and never a cool grey. Ramp: `--eg-050` → `--eg-900`.
- **Four state hues, and only four — refined, never primary/generic.** `--state-active` electric blue, `--state-attention` amber, `--state-success` **jade** (a cool, slightly deepened green, not a primary green), `--state-alert` **crimson** (a deep, slightly desaturated red, not a primary red). Generic red/green read as default-palette and undercut the material work everywhere else.
- **Every state indicator is contrast-checked at DOT size, not just badge size, against the surface it actually sits on** (`--panel-base`, i.e. inside a card or table row — not the bare page field, which flatters every value). A hue that reads fine as a filled pill can vanish as a 7px dot on a near-white card, so light mode is tuned independently — the dark hex values are never reused. Measured on the panel surface — dark: blue 5.14:1 · amber 9.44:1 · jade 7.69:1 · crimson 4.86:1 · idle 3.25:1; light: blue 5.70:1 · amber 5.44:1 · jade 5.55:1 · crimson 7.01:1 · idle 6.22:1. Light-mode dots also swap the outward glow (which halos and costs edge definition on a light field) for a tight contrast ring. In dark mode badges are washed tints with a coloured edge; in light mode they flip to **saturated fills with white text** at 5.6–7.3:1. See the **State contrast** card.
- **One narrow category accent: indigo.** `--accent-infra` is the ambient identity for infrastructure/management surfaces (Connections, Settings) only. It is a **category** signal, never a task state, and is deliberately far from crimson so the two can't be confused. A real problem inside an infrastructure tile still uses crimson, on that specific line item.
- No gradient-mesh washes, no rainbow bleeds, no bluish-purple gradients. The only gradients in the system are the matte pass, the reflective sheen and the chrome material itself.

### Typography

Three faces, three jobs, never swapped.

- **General Sans** (`--font-display`) — module titles and section headers. Confident, slightly industrial, geometric, disciplined. Weight 600, tracking −0.022em.
- **Space Grotesk** (`--font-ui`) — labels, body, buttons, nav. The workhorse; low personality by design. Shared with the marketing site's default hero face, which is what ties the two experiences together.
- **Geist Mono** (`--font-mono`) — **every price, quantity, part number, lead time and PO/RFQ identifier, no exceptions.** Tabular figures are mandatory (`font-variant-numeric: tabular-nums lining-nums`). Proportional digits in a data context is an immediate "looks generated" signal.
- Product UI runs **dense**: body is 13px, not 16px. Scale runs 10 → 48px.
- **Micro-labels are the only uppercase in the system**: 10px, weight 500, tracking 0.10em, muted, set in Space Grotesk.

### Surface construction — the rule that matters most

**No surface is ever a single flat translucent layer with one soft shadow.** Every glass, chrome or panel surface is five stacked layers:

1. **Base fill** — the material itself
2. **Matte pass** — a subtle darkening gradient that grounds it and prevents a raw-blur look
3. **Grain** — noise at two tiers: page-level (`0.030`, near-imperceptible, on the field) and surface-level (`0.055`, per panel). Overlay blend in dark mode
4. **Reflective sheen** — a soft directional highlight, typically top-edge or diagonal. This is where "premium" comes from, not from blur amount
5. **Content**, above all of it

…over a **dual-stack shadow**, never a single stop:

- **Ambient** — large, soft, low opacity
- **Key** — tighter, darker, directional
- **Inset top highlight** — a 1px near-white inset line at low opacity

`box-shadow: 0 4px 12px rgba(0,0,0,.3)` is forbidden. It is the single most common tell of a generated surface. Use `--elev-1/2/3` and `--elev-inset`.

**Grain persists in light mode** at higher opacity (`0.040` / `0.070`) blended as **multiply** rather than overlay. Shadows soften in light mode; they never vanish, or surfaces go flat again.

### Z-layer discipline

The three tiers are deliberately far apart, not incremental — Z-1 must read as clearly lifted off the field and Z-2 as clearly floating above Z-1, in a still frame with motion off.

- **Z-0** — the field: grid, beams, page-level grain, plus `--field-vignette`, an inset darkening that makes the background visibly *recede* rather than sit flat behind everything. No cast shadow.
- **Z-1** — center stage, hub tiles, standard panels. Four-stop shadow (ambient + key + contact + inset highlight), full surface grain, matte + sheen.
- **Z-2** — the expanded floating oval, modals, anything above a Z-1. Five-stop shadow with an inset bottom shade, strongest grain, highest backdrop blur. `--elev-3` is reserved for the single topmost element in a stack.

See the **Z-hierarchy** and **Layer breakdown** cards for the side-by-side demonstration in both themes.

### Progress — what is and is not allowed

**Banned:** smooth or percentage fills, and generic spinners. They imply a precision an agent process does not have.

**Allowed:** the **segmented step indicator** (`StepIndicator`). Every segment maps to one real discrete step and takes its color from the state system — done green, active blue and breathing, attention amber, failed red, pending a recessed neutral well. It is the step-filmstrip pattern compressed into a bar for headers and tiles; `StepFilmstrip` remains the full narrative form. If you cannot name each segment as a concrete step, this is the wrong control.

### Hover feedback

**Hover is a neutral material response. It never implies state, least of all failure.** Every hub tile gets the same baseline on hover — a chrome/glass shine, a 1px lift, the cursor spotlight and a subtle tilt — regardless of what it contains. `active`, `attention` and `success` tiles may tint that spotlight, because those describe live process the tile is already displaying. `alert` and `idle` deliberately do not: a full-tile crimson flare fired by the cursor reads as "hovering broke something".

**A genuine problem surfaces as content, not as a hover colour** — an expired credential is a crimson preview row and a crimson head dot inside the tile, which are visible whether or not the cursor is anywhere near it.

**Infrastructure tiles carry the indigo category accent** (Connections, Settings) as their ambient hover identity and icon tint. Schedules and anything else with nothing pending gets the plain neutral shine.

**Hard rule: the Connections tile's border and background must never render crimson at any hover state.** Its ambient hover is indigo, full stop, regardless of contents. Only the specific status line for the affected connection — the word `expired` and its row — is crimson, along with the head dot. Nothing else on that tile, ever.

### Comparison rail

Horizontal overflow inside a module never falls back to a browser scrollbar — `.es-stage-lanes` suppresses its own. `ComparisonRail` replaces it: a thin glass track with a hairline border and grain (Pillar 1's material, scaled down), **segmented one tick per item** where the content has a natural discrete count, so the rail expresses real state rather than an interpolated position. Ticks carry state — stepped-through items read green, the visible range is the active marker, and an individual item can flag amber or red. The rail is **hover-reactive**: it lifts 1px and its ticks brighten, echoing the hub tile's response to presence. Both disable under reduced motion while position stays fully legible. Above 40 items it falls back to a continuous glowing thumb.

### Reflective sheen on text

The chrome material also renders as typography. `.es-sheen` runs off-white → matte asphalt in dark mode and inverts to near-black → warm grey in light mode — the same treatment as the marketing hero, carried into the product for a **narrow, semantic purpose**:

- **Allowed:** the wordmark, and headlines representing a resolved/committed state (a locked step, an issued PO, a `done` stage) **when they sit on the field or a panel**.
- **Forbidden — state:** anything active or ephemeral. Active headlines stay flat (`.es-flat-title`). A sheened active headline destroys the signal and turns the treatment into decoration.
- **Forbidden — background:** on top of an actual chrome surface. That surface is already the material; the gradient's dark half lands on the metal's bright bands and the headline disappears. Chrome surfaces use flat `var(--chrome-text)`.

### Persistent identity

The mark and wordmark are visible in a fixed location on **every** screen, modal and expanded sub-environment — an orientation requirement in an interface where the center stage shifts and tiles expand in place, not a branding nicety. Modeled on the marketing nav: anchored top-left, consolidating into a floating glass pill (`Identity variant="pill"`) where there is no rail to sit in. The `Dialog` carries its own anchored identity because the scrim dims the shell behind it.

### Materials

- **Glass** (`--glass-*`): crisp 1px hairline border that never blurs even when the interior does; tight 4–8px radius; inner top-edge highlight instead of a drop shadow; a faint cool blue-green cast so it reads as a distinct material rather than "blurred graphite". Semantic and **rare** — it means *active/ephemeral*, it is not the default treatment.
- **Chrome** (`--chrome-*`): a multi-stop metallic gradient with a stronger sheen. **Reserved exclusively for resolved, committed, executed states.** Never applied to anything in progress. Never forced into light mode — light mode replaces both glass and chrome with a single elevated surface.
- **Panel** (`--panel-*`): the calm review material. Solid, matte, grained, dual-shadowed.

### Borders, radii, cards

- Radii are tight on purpose: `3 / 5 / 7 / 10 / 12px`, plus a true pill for the floating oval, status badges and the search field. Nothing consumer-soft.
- Borders are hairlines (`--line-hairline` ~10% in dark, ~14% in light) stepping up to `--line-strong` on hover and to a **state-coloured edge** when a surface carries state.
- A card is: hairline border + tight radius + matte + grain + sheen + dual shadow. Colour on a card is always state, never decoration, and never a coloured left border.

### Spacing & layout

- 2px base, thirteen steps (`--space-1` … `--space-13`). Control heights are `26 / 32 / 40px`.
- The beam field grid pitch is `56px` with a `224px` major line.
- The rail is a fixed 56px. The floating oval is **fixed** to the bottom centre of the work area at all times — it is part of the environment, never docked into a panel.
- Detail panels are sticky at 366px; below 1180px they stack.

### Backgrounds & imagery — the persistent environment (Z-0)

The background is never an image. It is a constructed field: warm graphite (or eggshell), a two-weight grid, page-level grain, a recession vignette, and **beam particles** — small blue and jade travelling points with fading trails.

**The grid is ONE continuous environment, identical on every screen.** A user moving from the agent workspace to Quotes to Connections is moving through the same space — same grid pitch, same visibility, same treatment. A screen that renders its own background, or drops the grid because it is a "calm" surface, breaks the premise the whole system rests on. In the app the field is a single layer under the shell (`#app > .es-field`), not something each view re-renders. Calm surfaces stay calm by dropping the *beams* (`density="none"`), never the grid.

**Beams are placed one per viewport region, never randomly.** `BeamField` partitions the viewport into a cols × rows grid and puts exactly one beam in each, jittered inside its own region — `calm` 3×1, `standard` 4×2, `dense` 6×2. Random placement visibly clumps: the previous implementation stepped its offsets by a value that aliased against the modulus and put all eight beams between 11% and 18% of the width, i.e. entirely down the left edge. Check left/right and top/bottom balance before calling a beam pass done.

There is no photography, no illustration, no texture photograph in the product interface.

### Motion

- Easing: `--ease-standard` `cubic-bezier(.2,.8,.25,1)` for UI, `--ease-material` `cubic-bezier(.65,0,.35,1)` for the glass→chrome commit, plus enter/exit curves.
- Durations: 90 / 140 / 220 / 420ms, `--dur-demote` 640ms for a stage module shrinking into the filmstrip, `--dur-breathe` 5.2s for the ambient pulse, `--dur-beam` 3.4s for particle travel.
- **Hover** lifts border contrast and shadow, never opacity; state-carrying surfaces intensify their state glow rather than changing hue. **Press** is `scale(0.985)` — a small physical give, no colour flip.
- **Reduced motion** (`prefers-reduced-motion` or `data-motion="reduced"`): grid goes static, particles disappear, the stage module changes state instantly, tile expansion becomes a cut, glass→chrome becomes an instant swap, the voice waveform becomes a static level meter. Material duality, colour-as-state, the stage-plus-filmstrip layout, tile previews and the floating input all persist unchanged.

### Transparency & blur — when

Blur is used **only** where it means something: a glass surface (something active), a Z-2 scrim behind a modal, and the tooltip. It is never wallpaper, never stacked panel-on-panel, and never the default treatment. The dividing line the spec draws is *decorative-everywhere vs. semantic-and-rare* — not *translucent vs. not*.

---

## ICONOGRAPHY

- **Set: Lucide**, 2px stroke at 24px, no fills. 50 glyphs are vendored as raw SVGs in `assets/icons/` (copied from `github.com/lucide-icons/lucide`, ISC licence). **Flagged substitution:** no icon set was supplied with the spec, so Lucide was chosen as the closest match to the marketing site's thin geometric line work. Swap it out if Everstock has its own set.
- Icons render through the `Icon` component, which masks the SVG with `currentColor` so a glyph inherits state colour without a second file. `window.ES_ICON_BASE` relocates the folder for pages at a different depth.
- **Icons carry category; colour carries state.** This is the mechanism that keeps hue free for the state language — a quotes tile and an invoices tile differ by glyph, never by hue.
- **No emoji, ever.** No unicode characters standing in as icons (no ✓, →, •). No hand-drawn SVG. If a glyph is missing, add the real Lucide file to `assets/icons/`.
- Icon sizes track type: 11px inside a tag, 13–15px in controls, 16–18px in the rail. A status **dot** is not an icon — it is 7px of pure state colour with a glow.

---

## Logo — LOCKED

**The identity is the segmented-chrome lemniscate.** One continuous stroke that crosses itself diagonally at the centre, divided into **12 discrete chrome facets — 6 per lobe**, one material throughout — no split, no glass, no matte variant. This is final and in circulation everywhere.

| File | Use |
|---|---|
| `assets/logo-mark-{dark,light}.svg` | **Display cut** — 12 facets. The mark at 24px and up. |
| `assets/logo-mark-{dark,light}-sm.svg` | **Small cut** — 7 facets. Below 24px. |
| `assets/logo-appicon-{dark,light}.svg` | App-icon tile, display cut. 32px and up. |
| `assets/logo-appicon-{dark,light}-sm.svg` | App-icon tile, small cut. 16px favicon. |

**Locked specification — two cuts of one mark.** Same lemniscate, same chrome, same crossing; only the facet count and stroke weight change with scale.

| Cut | Facets | Stroke | Gap | Used |
|---|---|---|---|---|
| Display | 12 (6 per lobe) | 5.6 | 1.7% | 24px and up |
| Small | 7 | 7.4 | 4.2% | below 24px, and the 16px favicon |

Neither ever rotates. The chrome is a banded gradient with a masked specular pass, a masked occlusion pass and a lit core — real reflectivity, not flat grey. The small cut also inverts its metal: bright on graphite, dark on eggshell, so the silhouette carries where facet detail cannot.

**Why two cuts.** The facet gap is a percentage of *path* length, so it is scale-invariant: at a 16px tile the display cut's twelve gaps fall under one device pixel each and the form fragments — the continuous crossing, which is the whole point of the mark, is the first thing to go. The small cut trades facet count for a gap that survives ≥1.5px. `Identity` switches between them automatically at 24px.

**Verified by rasterising the real SVGs** and reading per-pixel luminance at 30 / 18 / 14 / 10px and 64 / 32 / 16px, both themes. The 18px and 14px marks hold both lobes and the crossing cleanly. **The 10px mark and the 16px favicon are the floor** — the silhouette and the crossing survive, but individual facets do not resolve. Below 10px, use a solid (ungapped) stroke.

**Lockup.** Mark + `Everstock` set in the UI face, uppercase, 0.20em tracking, carrying the chrome sheen (`.es-sheen`). Rendered by the `Identity` component, so every nav bar, modal and persistent-identity anchor composes it identically.

### Retired directions — kept, not deleted

| Direction | Status |
|---|---|
| **Chrome + glass window** (`brand-logo-glass-detail.card.html`) | **Live variant, motion contexts only** — onboarding and loading, where the beam can travel and the mark renders large. **Never a static icon, favicon or nav mark.** |
| **Duality splits** — chrome+glass, glass+concrete, chrome+carbon (`brand-logo-splits.card.html`) | Reference only. Implemented nowhere. |
| Full smooth chrome, matte concrete, full glass, open-loop, beam pass, faceted carbon (`brand-logo-directions.card.html`) | Archive. Implemented nowhere. |

The pre-lock raster extractions of the old two-ring form are parked in `assets/legacy/` — superseded, not for use.

**Ask:** the mark is now authored as vector here. If you have an official vector from a designer, send it and I will swap `assets/logo-mark-*.svg` for it; everything else references those two files, so it is a one-file change.

---

## Index

| Path | What it is |
|---|---|
| `styles.css` | The single entry point consumers link. Nothing but `@import` lines. |
| `tokens/` | `fonts` `color` `typography` `space` `radius` `elevation` `material` `motion` |
| `foundations/` | `base` (field, reset, reduced motion) · `surface` (the five-layer stack) · `type` · `field` · `controls` · `patterns` |
| `guidelines/` | 48 specimen cards — Colors, Type, Spacing, Material, Motion, Brand, Process, Light mode |
| `components/` | 29 components in 7 groups (below) |
| `templates/` | Two starting templates consuming projects can copy: **Agent workspace** (living surface) and **Review screen** (calm surface) |
| `ui_kits/everstock-app/` | Click-through recreation of the product interface — see its README |
| `assets/` | `logo-mark-{dark,light}.svg` (the locked mark), `logo-appicon-*.svg`, `assets/icons/` (50 Lucide SVGs), `assets/legacy/` (superseded pre-lock marks) |
| `SKILL.md` | Agent Skills manifest for use outside this project |

### Components

**core/** — `Icon` · `Button` · `IconButton` · `Input` · `Select` · `Checkbox` · `Radio` · `Switch` · `Tag` · `ThemeToggle`

**surfaces/** — `Surface` · `Card` · `Dialog`

**feedback/** — `StatusDot` · `StatusBadge` · `Toast` · `Tooltip`

**navigation/** — `Tabs` · `HubTile`

**data/** — `MicroLabel` · `DataValue` · `DataTable`

**presence/** — `BeamField` · `StageModule` · `StageFlow` · `StepFilmstrip` · `StepIndicator` · `ComparisonRail` · `FloatingInput`

**brand/** — `Identity` · `SheenText`

### Intentional additions

No component library or Figma file defined an inventory, so the standard primitive set was authored from the spec. These are additions the spec's patterns require and are not generic library filler:

- `Surface` — the five-layer material primitive; without it every consumer re-implements the forbidden flat card.
- `Icon` — a wrapper over the vendored Lucide set so glyphs inherit `currentColor`.
- `MicroLabel`, `DataValue`, `DataTable` — the typography spec makes tabular figures and the uppercase micro-label load-bearing; these encode that so it cannot be forgotten.
- `BeamField`, `StageModule`, `StepFilmstrip`, `FloatingInput`, `HubTile`, `StatusDot` — direct implementations of Pillars 3 and 4.
- `ThemeToggle` — light mode is a mandated deliverable; the toggle keeps it in front of whoever is building.
- `Identity` — the spec makes a fixed identity anchor a hard requirement on every screen and state; a component is the only way that survives contact with real screens.
- `SheenText` — encodes the narrow rule for chrome-as-typography so the treatment cannot leak onto active-state headlines.
- `StageFlow` — the vertical counterpart to `StageModule`: vertical stacking means movement between process stages, horizontal lanes mean depth within one task.
- `ComparisonRail` — the spec bans the default scrollbar inside a module; a component is the only way that rule survives.
- `StepIndicator` — formalizes the one permitted progress display so nobody reaches for a percentage bar.

### Guardrails checklist

- [ ] Both dark **and** light rendered this pass
- [ ] No flat single-layer card, anywhere
- [ ] Background reads warm graphite, not navy
- [ ] Chrome appears only on resolved/committed things, and rarely
- [ ] Sheen text appears only on the wordmark and resolved headlines
- [ ] Identity anchor visible on every screen, modal and sub-environment
- [ ] Every figure is Geist Mono with tabular figures
- [ ] Hue is state; category is icon/shape/position (indigo is the one sanctioned category accent, for infrastructure only)
- [ ] Every dot AND badge contrast-checked in light mode at real size
- [ ] Hover never implies state — real problems appear as content
- [ ] Same grid on every screen; beams cover left AND right
- [ ] Legible with motion off
- [ ] No smooth/percentage progress — segmented step indicators only
- [ ] No default scrollbar inside a module — comparison rail instead

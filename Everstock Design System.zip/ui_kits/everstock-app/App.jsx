const { BeamField } = window.EverstockDesignSystem_8b23c3;

const TITLES = {
  hub: ['Command hub', 'Six environments. Every tile shows what is happening inside it.'],
  workspace: ['Agent workspace', 'One unit of work at a time, with an interrupt always in reach.'],
  quotes: ['Quotes', 'Fast, dense, scannable — the calm side of the line.'],
  orders: ['Orders & invoices', 'Committed records. Nothing here is in motion.'],
  connections: ['Connections', 'Systems Everstock reads from and writes to.']
};

function App({ initialView = 'hub', initialTheme = 'dark' }) {
  const [view, setView] = React.useState(initialView);
  const [theme, setTheme] = React.useState(initialTheme);
  const [motion, setMotion] = React.useState('standard');
  React.useEffect(() => {
    const el = document.getElementById('app');
    el.setAttribute('data-theme', theme);
    el.setAttribute('data-motion', motion);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme, motion]);
  const [title, meta] = TITLES[view];
  // The grid is ONE persistent environment under every screen. Calm surfaces drop the
  // traveling beams (Pillar 4) but keep the identical field — they never lose the grid.
  const living = view === 'hub' || view === 'workspace';
  const density = !living ? 'none'
    : theme === 'light' ? 'calm'
    : view === 'workspace' ? 'dense' : 'standard';
  const inner = (
    <AppShell view={view} onView={setView} title={title} meta={meta} theme={theme} setTheme={setTheme} motion={motion} setMotion={setMotion}>
      {view === 'hub' ? <CommandHub onOpen={setView} /> : null}
      {view === 'workspace' ? <Workspace theme={theme} /> : null}
      {view === 'quotes' ? <QuotesScreen /> : null}
      {view === 'orders' ? <OrdersScreen /> : null}
      {view === 'connections' ? <ConnectionsScreen /> : null}
    </AppShell>
  );
  return <BeamField density={density}>{inner}</BeamField>;
}

Object.assign(window, { App, TITLES });

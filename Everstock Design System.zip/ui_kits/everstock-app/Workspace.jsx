const { StageModule, StepFilmstrip, Surface, MicroLabel, Button, StatusDot, DataValue, Dialog, Toast } = window.EverstockDesignSystem_8b23c3;

function Workspace() {
  const [lead, setLead] = React.useState(1);
  const [committed, setCommitted] = React.useState(false);
  const [confirm, setConfirm] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const [paused, setPaused] = React.useState(false);

  React.useEffect(() => {
    if (paused || committed) return;
    const t = setInterval(() => setLead(i => (i + 1) % window.ESK.lanes.length), 3200);
    return () => clearInterval(t);
  }, [paused, committed]);

  const steps = window.ESK.steps.map((s, i) =>
    committed && i === window.ESK.steps.length - 1 ? { title: 'PO-2291 issued', value: '$18,240' } : s);

  return (
    <div className="esk-workspace">
      <StageModule
        title={committed ? 'PO-2291 issued to Meridian Supply' : 'Comparing 14 vendor quotes'}
        subtitle={committed ? 'Confirmed 4 seconds ago · delivery 12 Mar' : 'Brake rotors · 480 units · delivery by 12 Mar'}
        state={paused ? 'attention' : 'active'}
        committed={committed}
        lanes={committed ? [] : window.ESK.lanes}
        leadIndex={lead}
        onInterrupt={committed ? undefined : () => setPaused(p => !p)}
        footer={committed
          ? <StatusDot state="success" label="Locked in — this cannot be undone" />
          : <StatusDot state={paused ? 'attention' : 'active'} pulse label={paused ? 'Paused — waiting on you' : `Evaluating ${window.ESK.lanes[lead].title}`} />}
      >
        {committed ? (
          <div style={{ display: 'flex', gap: 'var(--space-10)', marginTop: 'var(--space-7)' }}>
            <DataValue label="Landed total" prefix="$" value="18,240" size="xl" />
            <DataValue label="Unit price" prefix="$" value="38.00" size="xl" />
            <DataValue label="Lead time" value="6" unit="days" size="xl" />
          </div>
        ) : null}
      </StageModule>

      <div className="esk-strip-head">
        <MicroLabel>Resolved steps</MicroLabel>
        {!committed ? <Button size="sm" variant="primary" icon="check" onClick={() => setConfirm(true)}>Award to Meridian</Button> : null}
      </div>
      <StepFilmstrip steps={steps} />

      <Surface material="panel" z={1} className="esk-note">
        <MicroLabel>Next stage</MicroLabel>
        <p className="es-body" style={{ marginTop: 6 }}>
          Once awarded, Everstock issues the PO, files it against the open requisition and watches the vendor inbox for an acknowledgement. You will only hear from it again if something needs you.
        </p>
      </Surface>

      <Dialog open={confirm} title="Award to Meridian Supply?"
        description="PO-2291 · 480 units · $18,240 landed. Issuing the order is a committed action and cannot be undone."
        onClose={() => setConfirm(false)}
        footer={<>
          <Button variant="ghost" onClick={() => setConfirm(false)}>Keep comparing</Button>
          <Button variant="primary" icon="lock" onClick={() => { setConfirm(false); setCommitted(true); setToast(true); }}>Issue PO</Button>
        </>} />

      {toast ? (
        <div className="esk-toasts">
          <Toast state="success" title="PO-2291 issued" description="Meridian Supply acknowledged in 40 seconds." onClose={() => setToast(false)} />
        </div>
      ) : null}
    </div>
  );
}

Object.assign(window, { Workspace });

# Everstock product app — UI kit

A click-through recreation of the Everstock **product interface** (the live application), built entirely from this design system's components. Open `index.html`.

## What is here

| Screen | File | Line it sits on |
|---|---|---|
| Command hub | `CommandHub.jsx` | Living — bento tiles with state-coloured spotlight, edge glow and beam particles |
| Agent workspace | `Workspace.jsx` | Living — center stage, horizontal vendor lanes, filmstrip, glass→chrome commit |
| Quotes | `QuotesScreen.jsx` | Calm — dense table plus a glass detail panel |
| Orders & invoices | `OrdersScreen.jsx` | Calm — committed records, no motion |
| Connections | `ConnectionsScreen.jsx` | Calm — integration list plus autonomy settings |
| Shell | `AppShell.jsx` | Rail, top bar, floating input slot |
| Layout only | `kit.css` | Composition; every material comes from `styles.css` |
| Fixture data | `data.js` | Auto-parts **and** electronics lines, to keep the kit vertical-agnostic |

## Interactions worth trying

- **Hub → tile** — click any tile to enter that sub-environment; "Watch" on the live strip jumps to the workspace.
- **Workspace** — lanes advance every 3.2s (horizontal progressive disclosure). *Interrupt* pauses the agent and flips the module to the attention state. *Award to Meridian* opens the commit dialog; confirming swaps the module from **glass to chrome** — the material event that says the PO is real.
- **Quotes** — select any row to load the glass detail panel; the panel's edge takes that row's state colour.
- **Theme** — the dark/light toggle in the top bar. Light mode is a required deliverable, not a variant.
- **Motion** — the play/pause button in the top bar sets `data-motion="reduced"`, which is the manual mirror of `prefers-reduced-motion`. Particles and tilt drop out; material, state colour and layout stay fully legible.

## Deliberate omissions

Everything shown is defined by the design system spec. No screens were invented for surfaces the spec does not describe — there is no CRM, no analytics dashboard and no reporting builder, because Everstock's hub is explicitly not a CRM. Vendor names, part numbers and figures are fixtures.

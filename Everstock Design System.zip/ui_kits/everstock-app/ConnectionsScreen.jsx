const { Surface, Card, Switch, StatusBadge, StatusDot, Button, Icon, MicroLabel, Input, Select, Radio, Checkbox, Tag } = window.EverstockDesignSystem_8b23c3;

function ConnectionsScreen() {
  const [rows, setRows] = React.useState(window.ESK.connections);
  const toggle = (id) => setRows(rs => rs.map(r => r.id === id ? { ...r, on: !r.on } : r));
  return (
    <div className="esk-two">
      <div className="esk-col">
        <MicroLabel>Connected systems</MicroLabel>
        <div className="esk-conn">
          {rows.map(c => (
            <Surface key={c.id} material="panel" z={1} state={c.state === 'alert' ? 'alert' : undefined} padded>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-5)' }}>
                <span className="es-tile-icon"><Icon name={c.icon} size={15} /></span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)' }}>
                    <p className="es-subtitle" style={{ fontSize: 'var(--text-sm)' }}>{c.name}</p>
                    <Tag>{c.kind}</Tag>
                  </div>
                  <p className="es-caption" style={{ marginTop: 4 }}>{c.detail}</p>
                  {c.state === 'alert' ? (
                    <Button size="sm" variant="secondary" icon="refresh-cw" style={{ marginTop: 10 }}>Reconnect</Button>
                  ) : null}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-5)' }}>
                  <StatusDot state={c.state} pulse={c.state === 'active'} />
                  <Switch checked={c.on} onChange={() => toggle(c.id)} />
                </div>
              </div>
            </Surface>
          ))}
        </div>
      </div>
      <aside className="esk-detail">
        <Card material="panel" z={1} dense title="Agent autonomy" subtitle="How far Everstock goes before it stops for you">
          <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
            <Radio name="autonomy" label="Ask before every outbound message" description="Slowest, fully supervised" />
            <Radio name="autonomy" label="Send RFQs, stop before awarding" description="Recommended" defaultChecked />
            <Radio name="autonomy" label="Award up to a spend ceiling" description="Fastest for repeat lines" />
          </div>
          <hr className="es-rule" style={{ margin: 'var(--space-7) 0' }} />
          <div style={{ display: 'grid', gap: 'var(--space-6)' }}>
            <Input label="Spend ceiling per order" mono defaultValue="25,000" />
            <Select label="Currency" options={[{ value: 'usd', label: 'USD' }, { value: 'eur', label: 'EUR' }, { value: 'gbp', label: 'GBP' }]} />
            <Checkbox label="Escalate if no vendor reply in 48 hours" defaultChecked />
            <Checkbox label="Include freight in every comparison" defaultChecked />
          </div>
          <div style={{ display: 'flex', gap: 'var(--gap-inline)', marginTop: 'var(--space-8)' }}>
            <Button size="sm" variant="primary">Save</Button>
            <Button size="sm" variant="ghost">Discard</Button>
          </div>
        </Card>
      </aside>
    </div>
  );
}

Object.assign(window, { ConnectionsScreen });

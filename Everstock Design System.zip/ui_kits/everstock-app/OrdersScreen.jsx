const { Tabs, DataTable, Surface, StatusDot, StatusBadge, Tag, Button, IconButton, MicroLabel, DataValue } = window.EverstockDesignSystem_8b23c3;

function OrdersScreen() {
  const [tab, setTab] = React.useState('orders');
  const isOrders = tab === 'orders';

  const orderCols = [
    { key: 'id', label: 'PO', render: r => <Tag mono>{r.id}</Tag> },
    { key: 'vendor', label: 'Vendor', render: r => (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: 'var(--text-primary)' }}>
        <StatusDot state={r.state} pulse={r.state === 'active'} />{r.vendor}
      </span>) },
    { key: 'items', label: 'Units', numeric: true },
    { key: 'total', label: 'Total', numeric: true, render: r => '$' + r.total },
    { key: 'issued', label: 'Issued', numeric: true },
    { key: 'eta', label: 'ETA', numeric: true },
    { key: 'status', label: 'Status', render: r => <StatusBadge state={r.state}>{r.status}</StatusBadge> }
  ];
  const invoiceCols = [
    { key: 'id', label: 'Invoice', render: r => <Tag mono>{r.id}</Tag> },
    { key: 'vendor', label: 'Vendor' },
    { key: 'po', label: 'Against PO', render: r => <Tag mono>{r.po}</Tag> },
    { key: 'total', label: 'Total', numeric: true, render: r => '$' + r.total },
    { key: 'due', label: 'Due', numeric: true },
    { key: 'status', label: 'Status', render: r => <StatusBadge state={r.state}>{r.status}</StatusBadge> }
  ];

  return (
    <div className="esk-col">
      <div className="esk-summary">
        <Surface material="panel" z={1} padded><DataValue label="Committed this month" prefix="$" value="182,470" size="lg" delta={-6.1} /></Surface>
        <Surface material="panel" z={1} padded><DataValue label="Open orders" value="27" size="lg" /></Surface>
        <Surface material="panel" z={1} padded><DataValue label="Awaiting approval" value="2" size="lg" state="attention" /></Surface>
        <Surface material="panel" z={1} padded><DataValue label="Late" value="1" size="lg" state="alert" /></Surface>
      </div>
      <div className="esk-toolbar">
        <Tabs value={tab} onChange={setTab} items={[
          { id: 'orders', label: 'Purchase orders', count: 27 },
          { id: 'invoices', label: 'Invoices', count: 4 }
        ]} />
        <div style={{ display: 'flex', gap: 'var(--gap-inline)' }}>
          <IconButton icon="funnel" label="Filter" variant="bordered" />
          <IconButton icon="download" label="Export" variant="bordered" />
        </div>
      </div>
      <Surface material="panel" z={1} className="esk-tablewrap">
        <DataTable rowKey="id" columns={isOrders ? orderCols : invoiceCols} rows={isOrders ? window.ESK.orders : window.ESK.invoices} />
      </Surface>
      {!isOrders ? (
        <div style={{ display: 'flex', gap: 'var(--gap-inline)' }}>
          <Button size="sm" variant="primary" icon="check">Approve 2 invoices</Button>
          <Button size="sm" variant="ghost">Send to ERP</Button>
        </div>
      ) : null}
    </div>
  );
}

Object.assign(window, { OrdersScreen });

const { Icon, IconButton, ThemeToggle, StatusDot, Tooltip, FloatingInput, Identity } = window.EverstockDesignSystem_8b23c3;

function Rail({ view, onView, theme }) {
  return (
    <nav className="esk-rail">
      <Identity theme={theme} size="sm" showWordmark={false} href="#"
        onClick={(e) => { e.preventDefault(); onView('hub'); }} className="esk-brand" />
      <div className="esk-rail-items">
        {window.ESK.nav.map(n => (
          <Tooltip key={n.id} content={n.label} placement="right">
            <button className={'esk-railbtn' + (view === n.id ? ' is-on' : '')} onClick={() => onView(n.id)} aria-label={n.label} aria-current={view === n.id}>
              <Icon name={n.icon} size={17} />
            </button>
          </Tooltip>
        ))}
      </div>
      <div className="esk-rail-foot">
        <Tooltip content="Alerts" placement="right"><button className="esk-railbtn" aria-label="Alerts"><Icon name="bell" size={16} /><span className="es-dot es-dot-attention" style={{ position: 'absolute', top: 7, right: 7 }} /></button></Tooltip>
        <Tooltip content="You" placement="right"><button className="esk-railbtn" aria-label="Account"><Icon name="user" size={16} /></button></Tooltip>
      </div>
    </nav>
  );
}

function TopBar({ title, meta, theme, setTheme, motion, setMotion, right }) {
  return (
    <header className="esk-top">
      <div className="esk-top-left">
        <Identity theme={theme} size="sm" className="esk-topbrand" />
        <span className="esk-topdiv" aria-hidden="true" />
        <div>
          <h1 className="es-title" style={{ fontSize: 'var(--text-lg)' }}>{title}</h1>
          {meta ? <p className="es-caption" style={{ marginTop: 2 }}>{meta}</p> : null}
        </div>
      </div>
      <div className="esk-top-right">
        {right}
        <label className="esk-search">
          <Icon name="search" size={14} />
          <input placeholder="Search parts, vendors, POs" aria-label="Search" />
        </label>
        <Tooltip content={motion === 'reduced' ? 'Motion reduced' : 'Motion standard'} placement="bottom">
          <IconButton icon={motion === 'reduced' ? 'pause' : 'play'} label="Motion" onClick={() => setMotion(motion === 'reduced' ? 'standard' : 'reduced')} />
        </Tooltip>
        <ThemeToggle value={theme} onChange={setTheme} target={document.getElementById('app')} />
      </div>
    </header>
  );
}

function AppShell({ view, onView, title, meta, theme, setTheme, motion, setMotion, topRight, children, oval = true }) {
  const [q, setQ] = React.useState('');
  const [listening, setListening] = React.useState(false);
  return (
    <div className="esk-shell">
      <Rail view={view} onView={onView} theme={theme} />
      <main className="esk-main">
        <TopBar title={title} meta={meta} theme={theme} setTheme={setTheme} motion={motion} setMotion={setMotion} right={topRight} />
        <div className="esk-body">{children}</div>
        {oval ? (
          <div className="esk-oval-slot">
            <FloatingInput value={q} onChange={setQ} listening={listening}
              onToggleVoice={() => setListening(v => !v)}
              onSubmit={() => { setQ(''); }} />
          </div>
        ) : null}
      </main>
    </div>
  );
}

Object.assign(window, { AppShell, Rail, TopBar });

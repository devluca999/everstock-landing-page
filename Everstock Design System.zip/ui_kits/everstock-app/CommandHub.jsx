const { HubTile, Surface, StatusDot, MicroLabel, Button, DataValue } = window.EverstockDesignSystem_8b23c3;

function CommandHub({ onOpen }) {
  return (
    <div className="esk-hub">
      <Surface material="glass" z={1} className="esk-livestrip">
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-6)' }}>
          <StatusDot state="active" pulse />
          <div>
            <MicroLabel>Working now</MicroLabel>
            <p className="es-subtitle" style={{ marginTop: 4 }}>Comparing 14 vendor quotes — brake rotors, 480 units</p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-9)' }}>
          <DataValue label="Best landed" prefix="$" value="18,240" delta={-4.2} align="right" />
          <DataValue label="Elapsed" value="00:41" align="right" />
          <Button variant="secondary" size="sm" iconRight="arrow-right" onClick={() => onOpen('workspace')}>Watch</Button>
        </div>
      </Surface>
      <div className="esk-bento">
        {window.ESK.tiles.map(t => (
          <HubTile key={t.id} icon={t.icon} title={t.title} state={t.state} category={t.category} meta={t.meta} preview={t.preview}
            onOpen={() => onOpen(t.id === 'invoices' || t.id === 'email' || t.id === 'schedules' ? 'orders' : t.id)} />
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { CommandHub });

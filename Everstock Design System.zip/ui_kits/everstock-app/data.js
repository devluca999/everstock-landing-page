window.ESK = {
  nav: [
    { id: 'hub', icon: 'layout-grid', label: 'Command hub' },
    { id: 'workspace', icon: 'bot', label: 'Agent workspace' },
    { id: 'quotes', icon: 'file-text', label: 'Quotes' },
    { id: 'orders', icon: 'receipt', label: 'Orders & invoices' },
    { id: 'connections', icon: 'plug', label: 'Connections' }
  ],
  tiles: [
    { id: 'quotes', icon: 'file-text', title: 'Quotes', state: 'active', meta: '3 vendors responding', preview: [{ label: 'Meridian Supply', value: '$18,240' }, { label: 'Northline Parts', value: '$18,905' }, { label: 'Delta Components', value: '$17,860' }] },
    { id: 'orders', icon: 'receipt', title: 'Purchase orders', state: 'success', meta: '2 issued today', preview: [{ label: 'PO-2291', value: '$18,240' }, { label: 'PO-2290', value: '$4,120' }] },
    { id: 'invoices', icon: 'circle-dollar-sign', title: 'Invoices', state: 'attention', meta: '2 need approval', preview: [{ label: 'INV-4417', value: '$6,300' }, { label: 'INV-4418', value: '$1,145' }] },
    { id: 'email', icon: 'mail', title: 'Email drafts', state: 'attention', meta: '1 awaiting your send', preview: [{ label: 'Re: rotor pricing', value: 'draft' }, { label: 'Q3 blanket order', value: 'draft' }] },
    { id: 'schedules', icon: 'calendar', title: 'Schedules', state: 'idle', meta: 'Next run 06:00', preview: [{ label: 'Reorder sweep', value: 'daily' }, { label: 'Vendor scorecard', value: 'weekly' }] },
    { id: 'connections', icon: 'plug', title: 'Connections', state: 'alert', category: 'infra', meta: '1 credential expired', preview: [{ label: 'NetSuite', value: 'ok' }, { label: 'Vendor portal · TRW', value: 'expired', state: 'alert' }] }
  ],
  lanes: [
    { id: 'v1', kicker: 'Vendor 01', title: 'Meridian Supply', rows: [{ label: 'Unit', value: '$38.00' }, { label: 'Freight', value: '$2.10' }, { label: 'Lead', value: '6 d' }, { label: 'Landed', value: '$18,240' }] },
    { id: 'v2', kicker: 'Vendor 02', title: 'Northline Parts', rows: [{ label: 'Unit', value: '$39.40' }, { label: 'Freight', value: '$0.00' }, { label: 'Lead', value: '4 d' }, { label: 'Landed', value: '$18,905' }] },
    { id: 'v3', kicker: 'Vendor 03', title: 'Delta Components', rows: [{ label: 'Unit', value: '$37.15' }, { label: 'Freight', value: '$4.05' }, { label: 'Lead', value: '11 d' }, { label: 'Landed', value: '$19,776' }] },
    { id: 'v4', kicker: 'Vendor 04', title: 'Halden Industrial', rows: [{ label: 'Unit', value: '$38.90' }, { label: 'Freight', value: '$1.40' }, { label: 'Lead', value: '7 d' }, { label: 'Landed', value: '$19,344' }] }
  ],
  steps: [
    { title: 'Demand parsed', value: '480 units' },
    { title: 'Vendors matched', value: '14 vendors' },
    { title: 'RFQs sent', value: '14 sent' },
    { title: 'Quotes returned', value: '11 of 14' },
    { title: 'Award & issue PO', pending: true }
  ],
  quotes: [
    { id: 'q1', vendor: 'Meridian Supply', part: 'BRK-4471-XL', desc: 'Vented brake rotor, 330mm', unit: '38.00', qty: '480', lead: '6', landed: '18,240', state: 'success', status: 'Best landed' },
    { id: 'q2', vendor: 'Northline Parts', part: 'BRK-4471-XL', desc: 'Vented brake rotor, 330mm', unit: '39.40', qty: '480', lead: '4', landed: '18,905', state: 'active', status: 'Negotiating' },
    { id: 'q3', vendor: 'Delta Components', part: 'BRK-4471-XL', desc: 'Vented brake rotor, 330mm', unit: '37.15', qty: '400', lead: '11', landed: '19,776', state: 'attention', status: 'Short qty' },
    { id: 'q4', vendor: 'Halden Industrial', part: 'BRK-4471-XL', desc: 'Vented brake rotor, 330mm', unit: '38.90', qty: '480', lead: '7', landed: '19,344', state: 'idle', status: 'Received' },
    { id: 'q5', vendor: 'Kestrel Electronics', part: 'CN-1108-D', desc: 'Board-to-board connector, 40p', unit: '2.14', qty: '12,000', lead: '18', landed: '26,880', state: 'active', status: 'Negotiating' },
    { id: 'q6', vendor: 'Arcline Components', part: 'CN-1108-D', desc: 'Board-to-board connector, 40p', unit: '2.31', qty: '12,000', lead: '9', landed: '28,344', state: 'idle', status: 'Received' },
    { id: 'q7', vendor: 'Volta Distribution', part: 'MCU-33F-QFN', desc: '32-bit MCU, QFN-48', unit: '4.86', qty: '5,000', lead: '22', landed: '24,300', state: 'alert', status: 'No stock' }
  ],
  orders: [
    { id: 'PO-2291', vendor: 'Meridian Supply', items: '480', total: '18,240', issued: '2026-03-04', eta: '2026-03-12', state: 'success', status: 'Issued' },
    { id: 'PO-2290', vendor: 'Kestrel Electronics', items: '12,000', total: '26,880', issued: '2026-03-04', eta: '2026-03-26', state: 'success', status: 'Issued' },
    { id: 'PO-2289', vendor: 'Halden Industrial', items: '240', total: '9,336', issued: '2026-03-02', eta: '2026-03-09', state: 'active', status: 'In transit' },
    { id: 'PO-2287', vendor: 'Arcline Components', items: '6,000', total: '13,860', issued: '2026-02-27', eta: '2026-03-08', state: 'attention', status: 'Partial' },
    { id: 'PO-2284', vendor: 'Delta Components', items: '400', total: '14,860', issued: '2026-02-24', eta: '2026-03-01', state: 'alert', status: 'Late' }
  ],
  invoices: [
    { id: 'INV-4417', vendor: 'Meridian Supply', po: 'PO-2291', total: '6,300', due: '2026-03-18', state: 'attention', status: 'Needs approval' },
    { id: 'INV-4418', vendor: 'Kestrel Electronics', po: 'PO-2290', total: '1,145', due: '2026-03-20', state: 'attention', status: 'Needs approval' },
    { id: 'INV-4411', vendor: 'Halden Industrial', po: 'PO-2289', total: '9,336', due: '2026-03-11', state: 'success', status: 'Paid' },
    { id: 'INV-4402', vendor: 'Arcline Components', po: 'PO-2287', total: '13,860', due: '2026-03-05', state: 'alert', status: 'Overdue' }
  ],
  connections: [
    { id: 'netsuite', icon: 'building-2', name: 'NetSuite', kind: 'ERP', state: 'success', detail: 'Synced 4 minutes ago', on: true },
    { id: 'trw', icon: 'truck', name: 'TRW vendor portal', kind: 'Vendor portal', state: 'alert', detail: 'Credential expired 2 days ago', on: true },
    { id: 'mail', icon: 'mail', name: 'Procurement inbox', kind: 'Email', state: 'active', detail: 'Watching 3 threads', on: true },
    { id: 'edi', icon: 'link', name: 'EDI 850 / 855', kind: 'Transport', state: 'success', detail: '212 documents this month', on: true },
    { id: 'wms', icon: 'package', name: 'Warehouse counts', kind: 'Inventory', state: 'idle', detail: 'Not connected', on: false }
  ]
};

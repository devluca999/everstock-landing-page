const { Tabs, DataTable, Surface, Card, StatusDot, StatusBadge, Tag, Button, IconButton, MicroLabel, DataValue, Input, Checkbox } = window.EverstockDesignSystem_8b23c3;

function QuotesScreen() {
  const [tab, setTab] = React.useState('open');
  const [sel, setSel] = React.useState('q1');
  const rows = window.ESK.quotes;
  const active = rows.find(r => r.id === sel) || rows[0];

  const columns = [
    { key: 'vendor', label: 'Vendor', render: r => (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: 'var(--text-primary)' }}>
        <StatusDot state={r.state} pulse={r.state === 'active'} />{r.vendor}
      </span>) },
    { key: 'part', label: 'Part', render: r => <Tag mono>{r.part}</Tag> },
    { key: 'desc', label: 'Description' },
    { key: 'unit', label: 'Unit', numeric: true, render: r => '$' + r.unit },
    { key: 'qty', label: 'Qty', numeric: true },
    { key: 'lead', label: 'Lead (d)', numeric: true },
    { key: 'landed', label: 'Landed', numeric: true, render: r => '$' + r.landed },
    { key: 'status', label: 'Status', render: r => <StatusBadge state={r.state}>{r.status}</StatusBadge> }
  ];

  return (
    <div className="esk-two">
      <div className="esk-col">
        <div className="esk-toolbar">
          <Tabs value={tab} onChange={setTab} items={[
            { id: 'open', label: 'Open', count: 7 },
            { id: 'awarded', label: 'Awarded', count: 6 },
            { id: 'closed', label: 'Closed', count: 212 }
          ]} />
          <div style={{ display: 'flex', gap: 'var(--gap-inline)', alignItems: 'center' }}>
            <IconButton icon="funnel" label="Filter" variant="bordered" />
            <IconButton icon="download" label="Export" variant="bordered" />
            <Button size="sm" variant="primary" icon="plus">New RFQ</Button>
          </div>
        </div>
        <Surface material="panel" z={1} className="esk-tablewrap">
          <DataTable columns={columns} rows={rows} rowKey="id" selectedId={sel} onSelect={r => setSel(r.id)} />
        </Surface>
        <p className="es-caption">Review surfaces stay calm on purpose — no motion, no glass, no glow. The only presence here is the live-status dot.</p>
      </div>

      <aside className="esk-detail">
        <Card material="glass" z={2} state={active.state === 'idle' ? undefined : active.state} dense
          title={active.vendor}
          subtitle={active.desc}
          actions={<IconButton icon="external-link" label="Open vendor" />}
          footer={<>
            <Button size="sm" variant="primary" icon="check">Award</Button>
            <Button size="sm" variant="ghost">Counter</Button>
          </>}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-7)' }}>
            <DataValue label="Unit price" prefix="$" value={active.unit} size="lg" />
            <DataValue label="Quantity" value={active.qty} size="lg" />
            <DataValue label="Lead time" value={active.lead} unit="days" size="lg" />
            <DataValue label="Landed" prefix="$" value={active.landed} size="lg" />
          </div>
          <hr className="es-rule" style={{ margin: 'var(--space-7) 0' }} />
          <MicroLabel>Agent note</MicroLabel>
          <p className="es-body" style={{ marginTop: 6 }}>
            {active.state === 'alert'
              ? 'Vendor reports no stock against this part. Everstock has paused outreach and needs a decision before substituting.'
              : 'Freight quoted separately and folded into landed cost. Everstock is holding this quote open until the last vendor replies.'}
          </p>
          <div style={{ display: 'flex', gap: 'var(--gap-inline)', marginTop: 'var(--space-6)', flexWrap: 'wrap' }}>
            <Tag mono>{active.part}</Tag><Tag icon="truck">Freight included</Tag><Tag icon="clock">Holds 48h</Tag>
          </div>
        </Card>
      </aside>
    </div>
  );
}

Object.assign(window, { QuotesScreen });

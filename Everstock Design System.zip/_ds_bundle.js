/* @ds-bundle: {"format":4,"namespace":"EverstockDesignSystem_8b23c3","components":[{"name":"Identity","sourcePath":"components/brand/Identity.jsx"},{"name":"SheenText","sourcePath":"components/brand/SheenText.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Radio","sourcePath":"components/core/Radio.jsx"},{"name":"Select","sourcePath":"components/core/Select.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ThemeToggle","sourcePath":"components/core/ThemeToggle.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"DataValue","sourcePath":"components/data/DataValue.jsx"},{"name":"MicroLabel","sourcePath":"components/data/MicroLabel.jsx"},{"name":"StatusBadge","sourcePath":"components/feedback/StatusBadge.jsx"},{"name":"StatusDot","sourcePath":"components/feedback/StatusDot.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"HubTile","sourcePath":"components/navigation/HubTile.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"BeamField","sourcePath":"components/presence/BeamField.jsx"},{"name":"ComparisonRail","sourcePath":"components/presence/ComparisonRail.jsx"},{"name":"FloatingInput","sourcePath":"components/presence/FloatingInput.jsx"},{"name":"StageFlow","sourcePath":"components/presence/StageFlow.jsx"},{"name":"StageModule","sourcePath":"components/presence/StageModule.jsx"},{"name":"StepFilmstrip","sourcePath":"components/presence/StepFilmstrip.jsx"},{"name":"StepIndicator","sourcePath":"components/presence/StepIndicator.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"Dialog","sourcePath":"components/surfaces/Dialog.jsx"},{"name":"Surface","sourcePath":"components/surfaces/Surface.jsx"}],"sourceHashes":{"components/brand/Identity.jsx":"890e55c2de84","components/brand/SheenText.jsx":"a07a5009637e","components/core/Button.jsx":"3257bc48f966","components/core/Checkbox.jsx":"09cb7e5e6a86","components/core/Icon.jsx":"78352a41eac5","components/core/IconButton.jsx":"44a2fcb2e78d","components/core/Input.jsx":"45e0499ab906","components/core/Radio.jsx":"0bfeb630bd80","components/core/Select.jsx":"bafbc1bbd429","components/core/Switch.jsx":"52a0ade3260e","components/core/Tag.jsx":"788e31671650","components/core/ThemeToggle.jsx":"92ba8888a085","components/data/DataTable.jsx":"3e832e5fc8d8","components/data/DataValue.jsx":"0f968fcb8828","components/data/MicroLabel.jsx":"faffc23b9f28","components/feedback/StatusBadge.jsx":"9892d921cf7b","components/feedback/StatusDot.jsx":"37f5d266f86b","components/feedback/Toast.jsx":"32df21ac1c01","components/feedback/Tooltip.jsx":"074ac44930e7","components/navigation/HubTile.jsx":"267e2fd3057f","components/navigation/Tabs.jsx":"216bfa4f8270","components/presence/BeamField.jsx":"533865574b46","components/presence/ComparisonRail.jsx":"e31570ab6457","components/presence/FloatingInput.jsx":"525d2266870c","components/presence/StageFlow.jsx":"7e193e060428","components/presence/StageModule.jsx":"c1f2c80241c2","components/presence/StepFilmstrip.jsx":"5f4772555b74","components/presence/StepIndicator.jsx":"5027b3858835","components/surfaces/Card.jsx":"25f5c5604200","components/surfaces/Dialog.jsx":"97b6219cfafb","components/surfaces/Surface.jsx":"c6a7c12b7e1e","ui_kits/everstock-app/App.jsx":"45ba18e82c75","ui_kits/everstock-app/AppShell.jsx":"9880e1a07dfd","ui_kits/everstock-app/CommandHub.jsx":"0a03985b379b","ui_kits/everstock-app/ConnectionsScreen.jsx":"805c56cb97ef","ui_kits/everstock-app/OrdersScreen.jsx":"a39a3c87080b","ui_kits/everstock-app/QuotesScreen.jsx":"a1f0ea935db1","ui_kits/everstock-app/Workspace.jsx":"1d6cedd26857","ui_kits/everstock-app/data.js":"4ff691aef29b"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EverstockDesignSystem_8b23c3 = window.EverstockDesignSystem_8b23c3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Identity.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Persistent identity anchor. Required on every screen, modal and expanded sub-environment. */
function Identity({
  variant = 'anchored',
  theme = 'dark',
  size = 'md',
  showWordmark = true,
  fixed = false,
  href = '#',
  onClick,
  className = '',
  style,
  ...rest
}) {
  const base = typeof window !== 'undefined' && window.ES_ASSET_BASE || 'assets/';
  const markH = size === 'sm' ? 14 : size === 'lg' ? 24 : 18;
  // Below ~24px the display cut's 8 facet gaps fall under a device pixel and the form
  // fragments, so the small cut (5 chunkier facets) takes over. Same mark, tuned for scale.
  const cut = markH < 24 ? '-sm' : '';
  const wordSize = size === 'sm' ? 'var(--text-2xs)' : size === 'lg' ? 'var(--text-sm)' : 'var(--text-xs)';
  const cls = ['es-identity', variant === 'pill' ? 'es-identity-pill' : 'es-identity-anchored', fixed ? 'es-identity-fixed' : '', showWordmark ? '' : 'es-identity-mark-only', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onClick: onClick,
    className: cls,
    "aria-label": "Everstock",
    style: {
      '--identity-mark': markH + 'px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: `${base}logo-mark-${theme}${cut}.svg`,
    alt: ""
  }), showWordmark ? /*#__PURE__*/React.createElement("span", {
    className: "es-wordmark es-sheen",
    style: {
      fontSize: wordSize
    }
  }, "Everstock") : null);
}
Object.assign(__ds_scope, { Identity });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Identity.jsx", error: String((e && e.message) || e) }); }

// components/brand/SheenText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Chrome-as-typography. Resolved/committed headlines and the wordmark only. */
function SheenText({
  as: Tag = 'span',
  tone = 'full',
  children,
  className = '',
  style,
  ...rest
}) {
  const cls = ['es-sheen', tone === 'soft' ? 'es-sheen-soft' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    style: style
  }, rest), children);
}
Object.assign(__ds_scope, { SheenText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/SheenText.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cache = new Map();

/** Lucide glyph, inlined so it inherits currentColor. Set window.ES_ICON_BASE to relocate the SVG folder. */
function Icon({
  name,
  size = 16,
  className = '',
  style,
  title,
  ...rest
}) {
  const base = typeof window !== 'undefined' && window.ES_ICON_BASE || 'assets/icons/';
  const url = base + name + '.svg';
  const [markup, setMarkup] = React.useState(() => cache.get(url) || null);
  React.useEffect(() => {
    let live = true;
    if (cache.has(url)) {
      setMarkup(cache.get(url));
      return;
    }
    fetch(url).then(r => r.ok ? r.text() : '').then(t => {
      const inner = t.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>[\s\S]*$/, '');
      cache.set(url, inner);
      if (live) setMarkup(inner);
    }).catch(() => {});
    return () => {
      live = false;
    };
  }, [url]);
  return /*#__PURE__*/React.createElement("svg", _extends({
    className: ('es-icon-svg ' + className).trim(),
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    role: title ? 'img' : undefined,
    "aria-label": title,
    "aria-hidden": title ? undefined : 'true',
    style: {
      flex: 'none',
      display: 'block',
      ...style
    },
    dangerouslySetInnerHTML: {
      __html: markup || ''
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Everstock button. `chrome` is reserved for committed/executed actions — use it sparingly. */
function Button({
  variant = 'secondary',
  size = 'md',
  icon,
  iconRight,
  loading = false,
  block = false,
  disabled = false,
  className = '',
  children,
  ...rest
}) {
  const cls = ['es-btn', `es-btn-${variant}`, size !== 'md' ? `es-btn-${size}` : '', block ? 'es-btn-block' : '', className].filter(Boolean).join(' ');
  const gl = size === 'lg' ? 16 : size === 'sm' ? 13 : 14;
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    disabled: disabled || loading
  }, rest), loading ? /*#__PURE__*/React.createElement("span", {
    className: "es-btn-spin"
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: gl
  }) : null, /*#__PURE__*/React.createElement("span", null, children), iconRight ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: gl
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox with the recessed-well box treatment. */
function Checkbox({
  label,
  description,
  disabled = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "es-box"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 11
  })), /*#__PURE__*/React.createElement("span", null, label, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      color: 'var(--text-faint)',
      fontSize: 'var(--text-2xs)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Square icon-only control. `label` is required — it becomes the accessible name. */
function IconButton({
  icon,
  label,
  size = 'md',
  variant = 'ghost',
  active = false,
  className = '',
  ...rest
}) {
  const cls = ['es-iconbtn', size !== 'md' ? `es-iconbtn-${size}` : '', variant === 'bordered' ? 'es-iconbtn-bordered' : '', active ? 'es-iconbtn-active' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    "aria-label": label,
    title: label
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'lg' ? 18 : size === 'sm' ? 13 : 15
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text field. Set mono for any numeric / identifier entry so figures stay tabular. */
function Input({
  label,
  hint,
  error,
  icon,
  size = 'md',
  mono = false,
  multiline = false,
  id,
  className = '',
  ...rest
}) {
  const uid = id || React.useId();
  const cls = ['es-control', size !== 'md' ? `es-control-${size}` : '', mono ? 'es-control-mono' : '', icon ? 'es-control-hasicon' : '', className].filter(Boolean).join(' ');
  const Tag = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("div", {
    className: "es-field-row"
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "es-micro",
    htmlFor: uid
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    style: {
      position: 'absolute',
      left: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--text-faint)',
      pointerEvents: 'none'
    }
  }) : null, /*#__PURE__*/React.createElement(Tag, _extends({
    id: uid,
    className: cls,
    "aria-invalid": error ? 'true' : undefined,
    style: icon ? {
      paddingLeft: 30
    } : undefined
  }, rest))), error ? /*#__PURE__*/React.createElement("p", {
    className: "es-hint es-hint-error"
  }, error) : hint ? /*#__PURE__*/React.createElement("p", {
    className: "es-hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Radio for one-of-N choices. Pass the same `name` to every member of a group. */
function Radio({
  label,
  description,
  disabled = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "es-box es-box-round"
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-box-dot"
  })), /*#__PURE__*/React.createElement("span", null, label, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      color: 'var(--text-faint)',
      fontSize: 'var(--text-2xs)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Radio.jsx", error: String((e && e.message) || e) }); }

// components/core/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native select wearing Everstock control chrome. Options are {value,label}. */
function Select({
  label,
  hint,
  options = [],
  size = 'md',
  id,
  className = '',
  ...rest
}) {
  const uid = id || React.useId();
  const cls = ['es-control', size !== 'md' ? `es-control-${size}` : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", {
    className: "es-field-row"
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "es-micro",
    htmlFor: uid
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    className: cls,
    style: {
      appearance: 'none',
      paddingRight: 28
    }
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 14,
    style: {
      position: 'absolute',
      right: 9,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--text-faint)',
      pointerEvents: 'none'
    }
  })), hint ? /*#__PURE__*/React.createElement("p", {
    className: "es-hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Select.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Switch for settings that take effect immediately (autonomy levels, notifications). */
function Switch({
  label,
  description,
  disabled = false,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' '),
    style: {
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "es-switch"
  }), /*#__PURE__*/React.createElement("span", null, label, description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      color: 'var(--text-faint)',
      fontSize: 'var(--text-2xs)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Neutral chip for CATEGORY, filter or identifier. Never carries state colour — use StatusBadge for that. */
function Tag({
  mono = false,
  selected = false,
  onRemove,
  icon,
  className = '',
  children,
  ...rest
}) {
  const cls = ['es-tag', mono ? 'es-tag-mono' : '', selected ? 'es-tag-selected' : '', onRemove ? 'es-tag-removable' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 11
  }) : null, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "es-tag-x",
    "aria-label": "Remove",
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 10
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/ThemeToggle.jsx
try { (() => {
/** Dark/light switcher. Writes data-theme onto the given root (defaults to <html>). */
function ThemeToggle({
  value,
  onChange,
  target,
  className = ''
}) {
  const [internal, setInternal] = React.useState(value || 'dark');
  const theme = value || internal;
  const set = t => {
    const el = target || (typeof document !== 'undefined' ? document.documentElement : null);
    if (el) el.setAttribute('data-theme', t);
    setInternal(t);
    if (onChange) onChange(t);
  };
  React.useEffect(() => {
    set(theme); /* eslint-disable-next-line */
  }, [value]);
  return /*#__PURE__*/React.createElement("div", {
    className: ['es-themetoggle', className].filter(Boolean).join(' '),
    role: "group",
    "aria-label": "Colour theme"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-pressed": theme === 'dark',
    onClick: () => set('dark')
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "moon",
    size: 12
  }), "Dark"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-pressed": theme === 'light',
    onClick: () => set('light')
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sun",
    size: 12
  }), "Light"));
}
Object.assign(__ds_scope, { ThemeToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ThemeToggle.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
/**
 * Dense review table. Deliberately calm — no motion, no glass, no glow.
 * columns: {key,label,numeric,width,render}. Numeric columns right-align and go monospace.
 */
function DataTable({
  columns = [],
  rows = [],
  selectedId,
  onSelect,
  rowKey = 'id',
  className = ''
}) {
  return /*#__PURE__*/React.createElement("table", {
    className: ['es-table', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    className: c.numeric ? 'es-th-num' : undefined,
    style: c.width ? {
      width: c.width
    } : undefined
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: r[rowKey] ?? i,
    "aria-selected": selectedId != null && r[rowKey] === selectedId ? 'true' : undefined,
    onClick: onSelect ? () => onSelect(r) : undefined,
    style: onSelect ? {
      cursor: 'pointer'
    } : undefined
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    className: c.numeric ? 'es-td-num' : undefined
  }, c.render ? c.render(r) : r[c.key]))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/MicroLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Small uppercase field label — the system's only uppercase role. */
function MicroLabel({
  as = 'span',
  className = '',
  children,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: ['es-micro', className].filter(Boolean).join(' ')
  }, rest), children);
}
Object.assign(__ds_scope, { MicroLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MicroLabel.jsx", error: String((e && e.message) || e) }); }

// components/data/DataValue.jsx
try { (() => {
/** Any price, quantity, identifier or lead time. Always monospace + tabular figures. */
function DataValue({
  label,
  value,
  unit,
  prefix,
  size = 'md',
  state,
  align = 'left',
  delta,
  className = ''
}) {
  const cls = ['es-num', size === 'lg' ? 'es-num-lg' : size === 'xl' ? 'es-num-xl' : '', className].filter(Boolean).join(' ');
  const deltaColor = delta == null ? null : delta < 0 ? 'var(--state-success)' : 'var(--state-alert)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      gap: 3,
      alignItems: align === 'right' ? 'flex-end' : 'flex-start'
    }
  }, label ? /*#__PURE__*/React.createElement(__ds_scope.MicroLabel, null, label) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: cls,
    style: state ? {
      color: `var(--state-${state})`
    } : undefined
  }, prefix, value), unit ? /*#__PURE__*/React.createElement("span", {
    className: "es-num es-num-muted",
    style: {
      fontSize: 'var(--text-2xs)'
    }
  }, unit) : null, delta != null ? /*#__PURE__*/React.createElement("span", {
    className: "es-num",
    style: {
      fontSize: 'var(--text-2xs)',
      color: deltaColor
    }
  }, delta > 0 ? '+' : '', delta, "%") : null));
}
Object.assign(__ds_scope, { DataValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataValue.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusDot.jsx
try { (() => {
/** Ambient state indicator — the only presence garnish allowed on calm review surfaces. */
function StatusDot({
  state = 'idle',
  pulse = false,
  label,
  className = ''
}) {
  const dot = /*#__PURE__*/React.createElement("span", {
    className: ['es-dot', `es-dot-${state}`, pulse ? 'es-dot-pulse' : '', className].filter(Boolean).join(' '),
    role: label ? 'img' : undefined,
    "aria-label": label
  });
  if (!label) return dot;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      color: 'var(--text-muted)',
      fontSize: 'var(--text-xs)'
    }
  }, dot, label);
}
Object.assign(__ds_scope, { StatusDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusDot.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusBadge.jsx
try { (() => {
/** State pill. Hue means state, never category — do not use this to label a task type. */
function StatusBadge({
  state = 'idle',
  dot = true,
  pulse = false,
  className = '',
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: ['es-badge', `es-badge-${state}`, className].filter(Boolean).join(' ')
  }, dot ? /*#__PURE__*/React.createElement(__ds_scope.StatusDot, {
    state: state,
    pulse: pulse
  }) : null, children);
}
Object.assign(__ds_scope, { StatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
/** Hover/focus tooltip on a glass surface. Keep to one short line. */
function Tooltip({
  content,
  placement = 'top',
  children,
  className = ''
}) {
  const [open, setOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    className: ['es-tooltip-wrap', className].filter(Boolean).join(' '),
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, children, open ? /*#__PURE__*/React.createElement("span", {
    className: `es-tooltip es-tooltip-${placement}`,
    role: "tooltip"
  }, content) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/navigation/HubTile.jsx
try { (() => {
/**
 * Command-hub bento tile. Hover is a NEUTRAL material response by default — spotlight, shine,
 * lift and tilt — because hovering must never itself imply state, least of all failure. Only
 * genuine content carries state: the head dot, and any preview row given its own `state`.
 * Infrastructure tiles (`category="infra"`) carry the indigo category accent as their ambient
 * identity instead. Tilt + particles drop out under reduced motion.
 */
function HubTile({
  icon,
  title,
  state = 'idle',
  category = 'process',
  meta,
  preview = [],
  onOpen,
  tilt = true,
  className = ''
}) {
  const ref = React.useRef(null);
  const [t, setT] = React.useState('');
  const move = e => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width,
      py = (e.clientY - r.top) / r.height;
    el.style.setProperty('--spot-x', `${px * 100}%`);
    el.style.setProperty('--spot-y', `${py * 100}%`);
    if (tilt) setT(`perspective(760px) rotateX(${(0.5 - py) * 6}deg) rotateY(${(px - 0.5) * 6}deg)`);
  };

  // Ambient identity ≠ state. Infrastructure is indigo; a live/awaiting process may tint its
  // own hover; alert and idle fall back to neutral so hover never reads as a failure flare.
  const ambient = category === 'infra' ? 'infra' : state === 'active' || state === 'attention' || state === 'success' ? state : 'neutral';
  const vars = ambient === 'infra' ? {
    '--tile-glow': 'var(--accent-infra-wash)',
    '--tile-glow-solid': 'var(--accent-infra)',
    '--tile-edge': 'var(--accent-infra-edge)'
  } : ambient === 'neutral' ? {
    '--tile-glow': 'var(--tile-shine)',
    '--tile-glow-solid': 'var(--text-faint)',
    '--tile-edge': 'var(--line-strong)'
  } : {
    '--tile-glow': `var(--state-${ambient}-wash)`,
    '--tile-glow-solid': `var(--state-${ambient})`,
    '--tile-edge': `var(--state-${ambient}-edge)`
  };
  return /*#__PURE__*/React.createElement("button", {
    ref: ref,
    type: "button",
    onMouseMove: move,
    onMouseLeave: () => setT(''),
    onClick: onOpen,
    className: ['es-tile', 'es-tilt', category === 'infra' ? 'es-tile-infra' : '', className].filter(Boolean).join(' '),
    style: {
      transform: t || undefined,
      ...vars
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-tile-spot"
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-tile-shine"
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-tile-particle",
    style: {
      left: '22%',
      animationDelay: '0s'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-tile-particle",
    style: {
      left: '64%',
      animationDelay: '1.1s'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-tile-particle",
    style: {
      left: '86%',
      animationDelay: '2.3s'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-tile-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-tile-icon"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15
  })), /*#__PURE__*/React.createElement(__ds_scope.StatusDot, {
    state: state,
    pulse: state === 'active'
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "es-tile-title",
    style: {
      display: 'block'
    }
  }, title), meta ? /*#__PURE__*/React.createElement("span", {
    className: "es-caption",
    style: {
      display: 'block',
      marginTop: 2
    }
  }, meta) : null), preview.length ? /*#__PURE__*/React.createElement("span", {
    className: "es-tile-preview"
  }, preview.map((p, i) => /*#__PURE__*/React.createElement("span", {
    className: ['es-tile-row', p.state ? 'es-tile-row-' + p.state : ''].filter(Boolean).join(' '),
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, p.label), /*#__PURE__*/React.createElement("span", {
    className: "es-num",
    style: {
      fontSize: 'var(--text-xs)'
    }
  }, p.value)))) : null);
}
Object.assign(__ds_scope, { HubTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/HubTile.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/** Underlined tabs for calm review surfaces. items: {id,label,count,icon}. */
function Tabs({
  items = [],
  value,
  onChange,
  className = ''
}) {
  const [internal, setInternal] = React.useState(value ?? items[0]?.id);
  const active = value ?? internal;
  const pick = id => {
    setInternal(id);
    if (onChange) onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: ['es-tabs', className].filter(Boolean).join(' '),
    role: "tablist"
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    className: "es-tab",
    role: "tab",
    "aria-selected": active === it.id,
    onClick: () => pick(it.id)
  }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 13
  }) : null, it.label, it.count != null ? /*#__PURE__*/React.createElement("span", {
    className: "es-tab-count"
  }, it.count) : null)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/presence/BeamField.jsx
try { (() => {
/**
 * Z-0 environment: the warm-graphite field, its grid, page-level grain and the traveling
 * beam particles. The GRID is the same on every screen — it is one persistent space the
 * product sits on, not a per-screen background — so only beam density varies by surface.
 * Beams are placed one per viewport region, never randomly: random placement visibly
 * clumps to one side. Particles are suppressed under reduced motion.
 */
function BeamField({
  density = 'standard',
  beams,
  className = '',
  style,
  children
}) {
  // cols × rows of guaranteed coverage. Every region gets exactly one beam.
  const layout = {
    none: [0, 0],
    calm: [3, 1],
    standard: [4, 2],
    dense: [6, 2]
  }[density] || [4, 2];
  const list = React.useMemo(() => {
    if (beams) return beams;
    const [cols, rows] = layout;
    const out = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i = r * cols + c;
        // Deterministic jitter inside the region — spread, but never leaving its region.
        const jx = i * 37 % 100 / 100,
          jy = i * 53 % 100 / 100;
        out.push({
          left: `${(c + 0.16 + jx * 0.68) / cols * 100}%`,
          top: `${(r + 0.10 + jy * 0.55) / rows * 62}%`,
          hue: i % 3 === 2 ? 'var(--state-success)' : 'var(--state-active)',
          delay: `${(i * 0.83 % 3.6).toFixed(2)}s`,
          dur: `${(3.2 + i % 4 * 0.9).toFixed(1)}s`
        });
      }
    }
    return out;
  }, [beams, density]);
  return /*#__PURE__*/React.createElement("div", {
    className: ['es-field', className].filter(Boolean).join(' '),
    style: style
  }, list.length ? /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 0,
      overflow: 'hidden',
      pointerEvents: 'none'
    }
  }, list.map((b, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-beam-particle",
    style: {
      position: 'absolute',
      left: b.left,
      top: b.top,
      width: 1,
      height: 46,
      background: `linear-gradient(180deg, transparent, ${b.hue})`,
      opacity: .45,
      animation: `es-beam ${b.dur} linear ${b.delay} infinite`
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-beam-particle",
    style: {
      position: 'absolute',
      left: b.left,
      top: b.top,
      width: 3,
      height: 3,
      borderRadius: '50%',
      background: b.hue,
      boxShadow: `0 0 10px 1px ${b.hue}`,
      animation: `es-beam ${b.dur} linear ${b.delay} infinite`
    }
  })))) : null, children);
}
Object.assign(__ds_scope, { BeamField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/BeamField.jsx", error: String((e && e.message) || e) }); }

// components/presence/ComparisonRail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The sanctioned horizontal-scroll affordance — a thin glass rail, segmented where the
 * content has a discrete count. Never a default browser scrollbar.
 */
function ComparisonRail({
  count = 0,
  index = 0,
  visible = 1,
  states = [],
  label,
  onSeek,
  scrollRef,
  className = '',
  style,
  ...rest
}) {
  const segmented = count > 0 && count <= 40;
  const seek = i => {
    if (onSeek) return onSeek(i);
    const el = scrollRef && scrollRef.current;
    if (!el || !count) return;
    el.scrollTo({
      left: el.scrollWidth / count * i,
      behavior: 'smooth'
    });
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ('es-crail-wrap ' + className).trim(),
    style: style
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "es-crail",
    role: "group",
    "aria-label": label || 'Scroll position'
  }, segmented ? Array.from({
    length: count
  }, (_, i) => {
    const s = states[i];
    const cls = ['es-crail-tick', s === 'attention' ? 'es-crail-tick-attention' : s === 'alert' ? 'es-crail-tick-alert' : '', i >= index && i < index + visible ? 'es-crail-tick-current' : i < index ? 'es-crail-tick-seen' : ''].filter(Boolean).join(' ');
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: cls,
      "aria-label": `Item ${i + 1} of ${count}`,
      "aria-current": i === index || undefined,
      onClick: () => seek(i)
    });
  }) : /*#__PURE__*/React.createElement("span", {
    className: "es-crail-thumb",
    style: {
      width: `${Math.max(8, visible / Math.max(count, 1) * 100)}%`,
      marginLeft: `${index / Math.max(count, 1) * 100}%`
    }
  })), count ? /*#__PURE__*/React.createElement("span", {
    className: "es-crail-count"
  }, String(Math.min(index + visible, count)).padStart(2, '0'), " / ", count) : null);
}
Object.assign(__ds_scope, { ComparisonRail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/ComparisonRail.jsx", error: String((e && e.message) || e) }); }

// components/presence/FloatingInput.jsx
try { (() => {
/**
 * The persistent floating oval. Minimal at rest, expands on focus, shows a live
 * waveform while listening. Never reads as a modal or a form field.
 */
function FloatingInput({
  placeholder = 'Tell Everstock what to do',
  value,
  onChange,
  onSubmit,
  listening = false,
  onToggleVoice,
  className = ''
}) {
  const [focused, setFocused] = React.useState(false);
  const bars = [6, 11, 16, 9, 14, 7, 12, 5];
  return /*#__PURE__*/React.createElement("form", {
    className: ['es-oval', focused || listening ? 'es-oval-expanded' : '', className].filter(Boolean).join(' '),
    style: {
      width: focused || listening ? 520 : 380
    },
    onSubmit: e => {
      e.preventDefault();
      if (onSubmit) onSubmit(value);
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sparkles",
    size: 14,
    style: {
      color: focused ? 'var(--state-active)' : 'var(--text-faint)'
    }
  }), listening ? /*#__PURE__*/React.createElement("span", {
    className: "es-wave",
    style: {
      flex: 1
    }
  }, bars.map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      height: h,
      animation: `es-breathe ${900 + i * 110}ms ease-in-out infinite`
    }
  }))) : /*#__PURE__*/React.createElement("input", {
    value: value,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false)
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: listening ? 'pause' : 'mic',
    label: listening ? 'Stop listening' : 'Speak',
    onClick: onToggleVoice,
    type: "button"
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "send",
    label: "Send",
    variant: "bordered",
    type: "submit"
  }));
}
Object.assign(__ds_scope, { FloatingInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/FloatingInput.jsx", error: String((e && e.message) || e) }); }

// components/presence/StageFlow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Vertical stage flow — movement between distinct process stages (sourcing → quoting → approval). */
function StageFlow({
  stages = [],
  className = '',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ('es-flow ' + className).trim(),
    style: style
  }, rest), stages.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.id || i,
    className: 'es-flow-row es-flow-' + (s.status || 'queued')
  }, /*#__PURE__*/React.createElement("div", {
    className: "es-flow-spine"
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-flow-node"
  })), /*#__PURE__*/React.createElement("div", {
    className: "es-flow-panel"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "es-subtitle",
    style: {
      fontSize: 'var(--text-sm)',
      color: s.status === 'done' ? 'inherit' : undefined
    }
  }, s.title), s.meta ? /*#__PURE__*/React.createElement("span", {
    className: "es-num",
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'inherit',
      opacity: .8
    }
  }, s.meta) : null), s.detail ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '5px 0 0',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-xs)',
      lineHeight: 1.45,
      color: s.status === 'done' ? 'inherit' : 'var(--text-muted)',
      opacity: s.status === 'done' ? .82 : 1
    }
  }, s.detail) : null))));
}
Object.assign(__ds_scope, { StageFlow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/StageFlow.jsx", error: String((e && e.message) || e) }); }

// components/presence/StepFilmstrip.jsx
try { (() => {
/**
 * The tray of resolved steps a center-stage module demotes into.
 * Resolved frames render in chrome; pending frames stay recessed and neutral.
 */
function StepFilmstrip({
  steps = [],
  className = ''
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ['es-filmstrip', className].filter(Boolean).join(' ')
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("article", {
    key: s.id ?? i,
    className: ['es-frame', s.pending ? 'es-frame-pending' : ''].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement(__ds_scope.MicroLabel, {
    style: {
      color: 'inherit',
      opacity: .7
    }
  }, s.pending ? 'Queued' : `Step ${i + 1}`), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '5px 0 0',
      fontSize: 'var(--text-xs)',
      fontWeight: 500,
      lineHeight: 1.3
    }
  }, s.title), s.value ? /*#__PURE__*/React.createElement("p", {
    className: "es-num",
    style: {
      margin: '6px 0 0',
      fontSize: 'var(--text-2xs)',
      color: 'inherit',
      opacity: .85
    }
  }, s.value) : null)));
}
Object.assign(__ds_scope, { StepFilmstrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/StepFilmstrip.jsx", error: String((e && e.message) || e) }); }

// components/presence/StepIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Segmented, state-colored step indicator. One segment = one real discrete step, never a percentage. */
function StepIndicator({
  steps = [],
  showLabels = false,
  caption,
  className = '',
  style,
  ...rest
}) {
  const done = steps.filter(s => s.status === 'done').length;
  const failed = steps.some(s => s.status === 'failed');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ('es-steps ' + className).trim(),
    style: style
  }, rest, {
    role: "group",
    "aria-label": caption || `Step ${Math.min(done + 1, steps.length)} of ${steps.length}`
  }), /*#__PURE__*/React.createElement("div", {
    className: "es-steps-bar"
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("span", {
    key: s.id ?? i,
    className: ['es-seg', s.status ? 'es-seg-' + s.status : ''].filter(Boolean).join(' '),
    title: s.label
  }))), showLabels ? /*#__PURE__*/React.createElement("div", {
    className: "es-steps-labels"
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("span", {
    key: s.id ?? i,
    className: ['es-steps-label', s.status === 'active' || s.status === 'failed' ? 'es-steps-label-on' : ''].filter(Boolean).join(' ')
  }, s.label))) : null, caption !== undefined ? /*#__PURE__*/React.createElement("div", {
    className: "es-steps-legend"
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-caption"
  }, caption), /*#__PURE__*/React.createElement("span", {
    className: "es-num",
    style: {
      fontSize: 'var(--text-2xs)',
      color: failed ? 'var(--state-alert)' : 'var(--text-faint)'
    }
  }, done, " / ", steps.length)) : null);
}
Object.assign(__ds_scope, { StepIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/StepIndicator.jsx", error: String((e && e.message) || e) }); }

// components/presence/StageModule.jsx
try { (() => {
/**
 * Center-stage module: the agent's current unit of work, given real visual weight.
 * Never a percentage or spinner — progress, when shown, is the segmented StepIndicator.
 * Glass while working; switches to chrome the moment the step commits.
 * `lanes` are horizontal progressive disclosure — depth within one task.
 */
function StageModule({
  title,
  subtitle,
  state = 'active',
  committed = false,
  lanes = [],
  leadIndex = 0,
  steps,
  railVisible = 4,
  railLabel,
  footer,
  onInterrupt,
  className = '',
  children
}) {
  const lanesRef = React.useRef(null);
  const [railIndex, setRailIndex] = React.useState(0);
  const showRail = lanes.length > railVisible;
  const seek = i => {
    setRailIndex(i);
    const el = lanesRef.current;
    if (el) el.scrollTo({
      left: el.scrollWidth / lanes.length * i,
      behavior: 'smooth'
    });
  };
  const cls = ['es-stage', committed ? 'es-stage-committed' : state === 'attention' ? 'es-stage-attention' : state === 'alert' ? 'es-stage-alert' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("section", {
    className: cls
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(__ds_scope.MicroLabel, null, committed ? 'Committed' : 'Working now'), /*#__PURE__*/React.createElement("h2", {
    className: "es-title",
    style: {
      marginTop: 6,
      color: committed ? 'var(--chrome-text)' : undefined
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    className: "es-body",
    style: {
      marginTop: 6
    }
  }, subtitle) : null), /*#__PURE__*/React.createElement(__ds_scope.StatusBadge, {
    state: committed ? 'success' : state,
    pulse: !committed && state === 'active'
  }, committed ? 'Locked in' : state === 'attention' ? 'Needs you' : state === 'alert' ? 'Blocked' : 'Live')), steps && steps.length ? /*#__PURE__*/React.createElement(__ds_scope.StepIndicator, {
    steps: steps,
    className: "",
    style: {
      marginTop: 'var(--space-6)'
    }
  }) : null, lanes.length ? /*#__PURE__*/React.createElement("div", {
    className: "es-stage-lanes",
    ref: lanesRef,
    style: {
      marginTop: 'var(--space-7)'
    }
  }, lanes.map((l, i) => /*#__PURE__*/React.createElement("article", {
    key: l.id ?? i,
    className: ['es-lane', i === leadIndex ? 'es-lane-lead' : ''].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement(__ds_scope.MicroLabel, null, l.kicker), /*#__PURE__*/React.createElement("p", {
    className: "es-body",
    style: {
      color: 'var(--text-primary)',
      marginTop: 5,
      fontWeight: 500
    }
  }, l.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      marginTop: 10
    }
  }, (l.rows || []).map((r, j) => /*#__PURE__*/React.createElement("div", {
    key: j,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-caption"
  }, r.label), /*#__PURE__*/React.createElement("span", {
    className: "es-num",
    style: {
      fontSize: 'var(--text-xs)'
    }
  }, r.value))))))) : null, showRail ? /*#__PURE__*/React.createElement(__ds_scope.ComparisonRail, {
    count: lanes.length,
    index: railIndex,
    visible: railVisible,
    label: railLabel || 'Comparison position',
    onSeek: seek,
    style: {
      marginTop: 'var(--space-5)'
    }
  }) : null, children, footer || onInterrupt ? /*#__PURE__*/React.createElement("footer", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      marginTop: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)',
      alignItems: 'center'
    }
  }, footer), onInterrupt ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "es-btn es-btn-ghost es-btn-sm",
    onClick: onInterrupt
  }, /*#__PURE__*/React.createElement("span", null, "Interrupt")) : null) : null);
}
Object.assign(__ds_scope, { StageModule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/presence/StageModule.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Surface.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The material primitive. Everything raised in Everstock is a Surface.
 * material: 'panel' (calm/dense) | 'glass' (active, ephemeral) | 'chrome' (resolved, committed).
 */
function Surface({
  material = 'panel',
  z = 1,
  state,
  padded = false,
  as = 'div',
  className = '',
  children,
  ...rest
}) {
  const Tag = as;
  const cls = ['es-surface', material === 'glass' ? 'es-glass' : material === 'chrome' ? 'es-chrome' : '', `es-z${z}`, state ? `es-state-${state}` : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    style: padded ? {
      padding: 'var(--pad-panel)'
    } : undefined
  }, rest), children);
}
Object.assign(__ds_scope, { Surface });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Surface.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/** Transient notice. The left rail carries the state colour; the surface stays glass. */
function Toast({
  state = 'active',
  title,
  description,
  action,
  onClose,
  className = ''
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Surface, {
    material: "glass",
    z: 2,
    className: ['es-toast', className].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-toast-rail",
    style: {
      background: `var(--state-${state})`
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "es-toast-body"
  }, /*#__PURE__*/React.createElement("p", {
    className: "es-toast-title"
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    className: "es-toast-desc"
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-5)'
    }
  }, action) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Dismiss",
    size: "sm",
    onClick: onClose
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Titled panel built on Surface. Use material="panel" on review/lookup screens. */
function Card({
  title,
  subtitle,
  actions,
  footer,
  material = 'panel',
  z = 1,
  state,
  dense = false,
  className = '',
  children,
  ...rest
}) {
  const pad = dense ? 'var(--pad-panel)' : 'var(--pad-panel-lg)';
  return /*#__PURE__*/React.createElement(__ds_scope.Surface, _extends({
    material: material,
    z: z,
    state: state,
    className: className
  }, rest), title || actions ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      padding: pad,
      paddingBottom: children ? 'var(--space-5)' : pad
    }
  }, /*#__PURE__*/React.createElement("div", null, title ? /*#__PURE__*/React.createElement("h3", {
    className: "es-subtitle"
  }, title) : null, subtitle ? /*#__PURE__*/React.createElement("p", {
    className: "es-caption",
    style: {
      marginTop: 2
    }
  }, subtitle) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)',
      flex: 'none'
    }
  }, actions) : null) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: pad,
      paddingTop: title || actions ? 0 : pad
    }
  }, children) : null, footer ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("hr", {
    className: "es-rule"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: pad,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--gap-inline)'
    }
  }, footer)) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Dialog.jsx
try { (() => {
/** Z-2 modal. Glass by default; use material="chrome" only to confirm something already committed. */
function Dialog({
  open = true,
  title,
  description,
  onClose,
  footer,
  material = 'glass',
  theme = 'dark',
  children
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "es-scrim",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title
  }, /*#__PURE__*/React.createElement(__ds_scope.Surface, {
    material: material,
    z: 3,
    className: "es-dialog"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      marginBottom: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Identity, {
    theme: theme,
    size: "sm"
  }), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    onClick: onClose
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "es-dialog-head"
  }, /*#__PURE__*/React.createElement("div", null, title ? /*#__PURE__*/React.createElement("h2", {
    className: "es-title",
    style: {
      fontSize: 'var(--text-lg)'
    }
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "es-body",
    style: {
      marginTop: 6
    }
  }, description) : null)), children, footer ? /*#__PURE__*/React.createElement("div", {
    className: "es-dialog-foot"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Dialog.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/App.jsx
try { (() => {
const {
  BeamField
} = window.EverstockDesignSystem_8b23c3;
const TITLES = {
  hub: ['Command hub', 'Six environments. Every tile shows what is happening inside it.'],
  workspace: ['Agent workspace', 'One unit of work at a time, with an interrupt always in reach.'],
  quotes: ['Quotes', 'Fast, dense, scannable — the calm side of the line.'],
  orders: ['Orders & invoices', 'Committed records. Nothing here is in motion.'],
  connections: ['Connections', 'Systems Everstock reads from and writes to.']
};
function App({
  initialView = 'hub',
  initialTheme = 'dark'
}) {
  const [view, setView] = React.useState(initialView);
  const [theme, setTheme] = React.useState(initialTheme);
  const [motion, setMotion] = React.useState('standard');
  React.useEffect(() => {
    const el = document.getElementById('app');
    el.setAttribute('data-theme', theme);
    el.setAttribute('data-motion', motion);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme, motion]);
  const [title, meta] = TITLES[view];
  // The grid is ONE persistent environment under every screen. Calm surfaces drop the
  // traveling beams (Pillar 4) but keep the identical field — they never lose the grid.
  const living = view === 'hub' || view === 'workspace';
  const density = !living ? 'none' : theme === 'light' ? 'calm' : view === 'workspace' ? 'dense' : 'standard';
  const inner = /*#__PURE__*/React.createElement(AppShell, {
    view: view,
    onView: setView,
    title: title,
    meta: meta,
    theme: theme,
    setTheme: setTheme,
    motion: motion,
    setMotion: setMotion
  }, view === 'hub' ? /*#__PURE__*/React.createElement(CommandHub, {
    onOpen: setView
  }) : null, view === 'workspace' ? /*#__PURE__*/React.createElement(Workspace, {
    theme: theme
  }) : null, view === 'quotes' ? /*#__PURE__*/React.createElement(QuotesScreen, null) : null, view === 'orders' ? /*#__PURE__*/React.createElement(OrdersScreen, null) : null, view === 'connections' ? /*#__PURE__*/React.createElement(ConnectionsScreen, null) : null);
  return /*#__PURE__*/React.createElement(BeamField, {
    density: density
  }, inner);
}
Object.assign(window, {
  App,
  TITLES
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/AppShell.jsx
try { (() => {
const {
  Icon,
  IconButton,
  ThemeToggle,
  StatusDot,
  Tooltip,
  FloatingInput,
  Identity
} = window.EverstockDesignSystem_8b23c3;
function Rail({
  view,
  onView,
  theme
}) {
  return /*#__PURE__*/React.createElement("nav", {
    className: "esk-rail"
  }, /*#__PURE__*/React.createElement(Identity, {
    theme: theme,
    size: "sm",
    showWordmark: false,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onView('hub');
    },
    className: "esk-brand"
  }), /*#__PURE__*/React.createElement("div", {
    className: "esk-rail-items"
  }, window.ESK.nav.map(n => /*#__PURE__*/React.createElement(Tooltip, {
    key: n.id,
    content: n.label,
    placement: "right"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'esk-railbtn' + (view === n.id ? ' is-on' : ''),
    onClick: () => onView(n.id),
    "aria-label": n.label,
    "aria-current": view === n.id
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon,
    size: 17
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "esk-rail-foot"
  }, /*#__PURE__*/React.createElement(Tooltip, {
    content: "Alerts",
    placement: "right"
  }, /*#__PURE__*/React.createElement("button", {
    className: "esk-railbtn",
    "aria-label": "Alerts"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    className: "es-dot es-dot-attention",
    style: {
      position: 'absolute',
      top: 7,
      right: 7
    }
  }))), /*#__PURE__*/React.createElement(Tooltip, {
    content: "You",
    placement: "right"
  }, /*#__PURE__*/React.createElement("button", {
    className: "esk-railbtn",
    "aria-label": "Account"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 16
  })))));
}
function TopBar({
  title,
  meta,
  theme,
  setTheme,
  motion,
  setMotion,
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "esk-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "esk-top-left"
  }, /*#__PURE__*/React.createElement(Identity, {
    theme: theme,
    size: "sm",
    className: "esk-topbrand"
  }), /*#__PURE__*/React.createElement("span", {
    className: "esk-topdiv",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "es-title",
    style: {
      fontSize: 'var(--text-lg)'
    }
  }, title), meta ? /*#__PURE__*/React.createElement("p", {
    className: "es-caption",
    style: {
      marginTop: 2
    }
  }, meta) : null)), /*#__PURE__*/React.createElement("div", {
    className: "esk-top-right"
  }, right, /*#__PURE__*/React.createElement("label", {
    className: "esk-search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 14
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search parts, vendors, POs",
    "aria-label": "Search"
  })), /*#__PURE__*/React.createElement(Tooltip, {
    content: motion === 'reduced' ? 'Motion reduced' : 'Motion standard',
    placement: "bottom"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: motion === 'reduced' ? 'pause' : 'play',
    label: "Motion",
    onClick: () => setMotion(motion === 'reduced' ? 'standard' : 'reduced')
  })), /*#__PURE__*/React.createElement(ThemeToggle, {
    value: theme,
    onChange: setTheme,
    target: document.getElementById('app')
  })));
}
function AppShell({
  view,
  onView,
  title,
  meta,
  theme,
  setTheme,
  motion,
  setMotion,
  topRight,
  children,
  oval = true
}) {
  const [q, setQ] = React.useState('');
  const [listening, setListening] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-shell"
  }, /*#__PURE__*/React.createElement(Rail, {
    view: view,
    onView: onView,
    theme: theme
  }), /*#__PURE__*/React.createElement("main", {
    className: "esk-main"
  }, /*#__PURE__*/React.createElement(TopBar, {
    title: title,
    meta: meta,
    theme: theme,
    setTheme: setTheme,
    motion: motion,
    setMotion: setMotion,
    right: topRight
  }), /*#__PURE__*/React.createElement("div", {
    className: "esk-body"
  }, children), oval ? /*#__PURE__*/React.createElement("div", {
    className: "esk-oval-slot"
  }, /*#__PURE__*/React.createElement(FloatingInput, {
    value: q,
    onChange: setQ,
    listening: listening,
    onToggleVoice: () => setListening(v => !v),
    onSubmit: () => {
      setQ('');
    }
  })) : null));
}
Object.assign(window, {
  AppShell,
  Rail,
  TopBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/CommandHub.jsx
try { (() => {
const {
  HubTile,
  Surface,
  StatusDot,
  MicroLabel,
  Button,
  DataValue
} = window.EverstockDesignSystem_8b23c3;
function CommandHub({
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-hub"
  }, /*#__PURE__*/React.createElement(Surface, {
    material: "glass",
    z: 1,
    className: "esk-livestrip"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(StatusDot, {
    state: "active",
    pulse: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(MicroLabel, null, "Working now"), /*#__PURE__*/React.createElement("p", {
    className: "es-subtitle",
    style: {
      marginTop: 4
    }
  }, "Comparing 14 vendor quotes \u2014 brake rotors, 480 units"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Best landed",
    prefix: "$",
    value: "18,240",
    delta: -4.2,
    align: "right"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Elapsed",
    value: "00:41",
    align: "right"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconRight: "arrow-right",
    onClick: () => onOpen('workspace')
  }, "Watch"))), /*#__PURE__*/React.createElement("div", {
    className: "esk-bento"
  }, window.ESK.tiles.map(t => /*#__PURE__*/React.createElement(HubTile, {
    key: t.id,
    icon: t.icon,
    title: t.title,
    state: t.state,
    category: t.category,
    meta: t.meta,
    preview: t.preview,
    onOpen: () => onOpen(t.id === 'invoices' || t.id === 'email' || t.id === 'schedules' ? 'orders' : t.id)
  }))));
}
Object.assign(window, {
  CommandHub
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/CommandHub.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/ConnectionsScreen.jsx
try { (() => {
const {
  Surface,
  Card,
  Switch,
  StatusBadge,
  StatusDot,
  Button,
  Icon,
  MicroLabel,
  Input,
  Select,
  Radio,
  Checkbox,
  Tag
} = window.EverstockDesignSystem_8b23c3;
function ConnectionsScreen() {
  const [rows, setRows] = React.useState(window.ESK.connections);
  const toggle = id => setRows(rs => rs.map(r => r.id === id ? {
    ...r,
    on: !r.on
  } : r));
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-two"
  }, /*#__PURE__*/React.createElement("div", {
    className: "esk-col"
  }, /*#__PURE__*/React.createElement(MicroLabel, null, "Connected systems"), /*#__PURE__*/React.createElement("div", {
    className: "esk-conn"
  }, rows.map(c => /*#__PURE__*/React.createElement(Surface, {
    key: c.id,
    material: "panel",
    z: 1,
    state: c.state === 'alert' ? 'alert' : undefined,
    padded: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "es-tile-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: c.icon,
    size: 15
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "es-subtitle",
    style: {
      fontSize: 'var(--text-sm)'
    }
  }, c.name), /*#__PURE__*/React.createElement(Tag, null, c.kind)), /*#__PURE__*/React.createElement("p", {
    className: "es-caption",
    style: {
      marginTop: 4
    }
  }, c.detail), c.state === 'alert' ? /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    icon: "refresh-cw",
    style: {
      marginTop: 10
    }
  }, "Reconnect") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(StatusDot, {
    state: c.state,
    pulse: c.state === 'active'
  }), /*#__PURE__*/React.createElement(Switch, {
    checked: c.on,
    onChange: () => toggle(c.id)
  }))))))), /*#__PURE__*/React.createElement("aside", {
    className: "esk-detail"
  }, /*#__PURE__*/React.createElement(Card, {
    material: "panel",
    z: 1,
    dense: true,
    title: "Agent autonomy",
    subtitle: "How far Everstock goes before it stops for you"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "autonomy",
    label: "Ask before every outbound message",
    description: "Slowest, fully supervised"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "autonomy",
    label: "Send RFQs, stop before awarding",
    description: "Recommended",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "autonomy",
    label: "Award up to a spend ceiling",
    description: "Fastest for repeat lines"
  })), /*#__PURE__*/React.createElement("hr", {
    className: "es-rule",
    style: {
      margin: 'var(--space-7) 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Spend ceiling per order",
    mono: true,
    defaultValue: "25,000"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Currency",
    options: [{
      value: 'usd',
      label: 'USD'
    }, {
      value: 'eur',
      label: 'EUR'
    }, {
      value: 'gbp',
      label: 'GBP'
    }]
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Escalate if no vendor reply in 48 hours",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Include freight in every comparison",
    defaultChecked: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)',
      marginTop: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary"
  }, "Save"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost"
  }, "Discard")))));
}
Object.assign(window, {
  ConnectionsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/ConnectionsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/OrdersScreen.jsx
try { (() => {
const {
  Tabs,
  DataTable,
  Surface,
  StatusDot,
  StatusBadge,
  Tag,
  Button,
  IconButton,
  MicroLabel,
  DataValue
} = window.EverstockDesignSystem_8b23c3;
function OrdersScreen() {
  const [tab, setTab] = React.useState('orders');
  const isOrders = tab === 'orders';
  const orderCols = [{
    key: 'id',
    label: 'PO',
    render: r => /*#__PURE__*/React.createElement(Tag, {
      mono: true
    }, r.id)
  }, {
    key: 'vendor',
    label: 'Vendor',
    render: r => /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        color: 'var(--text-primary)'
      }
    }, /*#__PURE__*/React.createElement(StatusDot, {
      state: r.state,
      pulse: r.state === 'active'
    }), r.vendor)
  }, {
    key: 'items',
    label: 'Units',
    numeric: true
  }, {
    key: 'total',
    label: 'Total',
    numeric: true,
    render: r => '$' + r.total
  }, {
    key: 'issued',
    label: 'Issued',
    numeric: true
  }, {
    key: 'eta',
    label: 'ETA',
    numeric: true
  }, {
    key: 'status',
    label: 'Status',
    render: r => /*#__PURE__*/React.createElement(StatusBadge, {
      state: r.state
    }, r.status)
  }];
  const invoiceCols = [{
    key: 'id',
    label: 'Invoice',
    render: r => /*#__PURE__*/React.createElement(Tag, {
      mono: true
    }, r.id)
  }, {
    key: 'vendor',
    label: 'Vendor'
  }, {
    key: 'po',
    label: 'Against PO',
    render: r => /*#__PURE__*/React.createElement(Tag, {
      mono: true
    }, r.po)
  }, {
    key: 'total',
    label: 'Total',
    numeric: true,
    render: r => '$' + r.total
  }, {
    key: 'due',
    label: 'Due',
    numeric: true
  }, {
    key: 'status',
    label: 'Status',
    render: r => /*#__PURE__*/React.createElement(StatusBadge, {
      state: r.state
    }, r.status)
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "esk-summary"
  }, /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    padded: true
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Committed this month",
    prefix: "$",
    value: "182,470",
    size: "lg",
    delta: -6.1
  })), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    padded: true
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Open orders",
    value: "27",
    size: "lg"
  })), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    padded: true
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Awaiting approval",
    value: "2",
    size: "lg",
    state: "attention"
  })), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    padded: true
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Late",
    value: "1",
    size: "lg",
    state: "alert"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "esk-toolbar"
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      id: 'orders',
      label: 'Purchase orders',
      count: 27
    }, {
      id: 'invoices',
      label: 'Invoices',
      count: 4
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "funnel",
    label: "Filter",
    variant: "bordered"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "download",
    label: "Export",
    variant: "bordered"
  }))), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    className: "esk-tablewrap"
  }, /*#__PURE__*/React.createElement(DataTable, {
    rowKey: "id",
    columns: isOrders ? orderCols : invoiceCols,
    rows: isOrders ? window.ESK.orders : window.ESK.invoices
  })), !isOrders ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    icon: "check"
  }, "Approve 2 invoices"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost"
  }, "Send to ERP")) : null);
}
Object.assign(window, {
  OrdersScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/OrdersScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/QuotesScreen.jsx
try { (() => {
const {
  Tabs,
  DataTable,
  Surface,
  Card,
  StatusDot,
  StatusBadge,
  Tag,
  Button,
  IconButton,
  MicroLabel,
  DataValue,
  Input,
  Checkbox
} = window.EverstockDesignSystem_8b23c3;
function QuotesScreen() {
  const [tab, setTab] = React.useState('open');
  const [sel, setSel] = React.useState('q1');
  const rows = window.ESK.quotes;
  const active = rows.find(r => r.id === sel) || rows[0];
  const columns = [{
    key: 'vendor',
    label: 'Vendor',
    render: r => /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        color: 'var(--text-primary)'
      }
    }, /*#__PURE__*/React.createElement(StatusDot, {
      state: r.state,
      pulse: r.state === 'active'
    }), r.vendor)
  }, {
    key: 'part',
    label: 'Part',
    render: r => /*#__PURE__*/React.createElement(Tag, {
      mono: true
    }, r.part)
  }, {
    key: 'desc',
    label: 'Description'
  }, {
    key: 'unit',
    label: 'Unit',
    numeric: true,
    render: r => '$' + r.unit
  }, {
    key: 'qty',
    label: 'Qty',
    numeric: true
  }, {
    key: 'lead',
    label: 'Lead (d)',
    numeric: true
  }, {
    key: 'landed',
    label: 'Landed',
    numeric: true,
    render: r => '$' + r.landed
  }, {
    key: 'status',
    label: 'Status',
    render: r => /*#__PURE__*/React.createElement(StatusBadge, {
      state: r.state
    }, r.status)
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-two"
  }, /*#__PURE__*/React.createElement("div", {
    className: "esk-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "esk-toolbar"
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      id: 'open',
      label: 'Open',
      count: 7
    }, {
      id: 'awarded',
      label: 'Awarded',
      count: 6
    }, {
      id: 'closed',
      label: 'Closed',
      count: 212
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "funnel",
    label: "Filter",
    variant: "bordered"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "download",
    label: "Export",
    variant: "bordered"
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    icon: "plus"
  }, "New RFQ"))), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    className: "esk-tablewrap"
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: columns,
    rows: rows,
    rowKey: "id",
    selectedId: sel,
    onSelect: r => setSel(r.id)
  })), /*#__PURE__*/React.createElement("p", {
    className: "es-caption"
  }, "Review surfaces stay calm on purpose \u2014 no motion, no glass, no glow. The only presence here is the live-status dot.")), /*#__PURE__*/React.createElement("aside", {
    className: "esk-detail"
  }, /*#__PURE__*/React.createElement(Card, {
    material: "glass",
    z: 2,
    state: active.state === 'idle' ? undefined : active.state,
    dense: true,
    title: active.vendor,
    subtitle: active.desc,
    actions: /*#__PURE__*/React.createElement(IconButton, {
      icon: "external-link",
      label: "Open vendor"
    }),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "check"
    }, "Award"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost"
    }, "Counter"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Unit price",
    prefix: "$",
    value: active.unit,
    size: "lg"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Quantity",
    value: active.qty,
    size: "lg"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Lead time",
    value: active.lead,
    unit: "days",
    size: "lg"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Landed",
    prefix: "$",
    value: active.landed,
    size: "lg"
  })), /*#__PURE__*/React.createElement("hr", {
    className: "es-rule",
    style: {
      margin: 'var(--space-7) 0'
    }
  }), /*#__PURE__*/React.createElement(MicroLabel, null, "Agent note"), /*#__PURE__*/React.createElement("p", {
    className: "es-body",
    style: {
      marginTop: 6
    }
  }, active.state === 'alert' ? 'Vendor reports no stock against this part. Everstock has paused outreach and needs a decision before substituting.' : 'Freight quoted separately and folded into landed cost. Everstock is holding this quote open until the last vendor replies.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--gap-inline)',
      marginTop: 'var(--space-6)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    mono: true
  }, active.part), /*#__PURE__*/React.createElement(Tag, {
    icon: "truck"
  }, "Freight included"), /*#__PURE__*/React.createElement(Tag, {
    icon: "clock"
  }, "Holds 48h")))));
}
Object.assign(window, {
  QuotesScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/QuotesScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/Workspace.jsx
try { (() => {
const {
  StageModule,
  StepFilmstrip,
  Surface,
  MicroLabel,
  Button,
  StatusDot,
  DataValue,
  Dialog,
  Toast
} = window.EverstockDesignSystem_8b23c3;
function Workspace() {
  const [lead, setLead] = React.useState(1);
  const [committed, setCommitted] = React.useState(false);
  const [confirm, setConfirm] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const [paused, setPaused] = React.useState(false);
  React.useEffect(() => {
    if (paused || committed) return;
    const t = setInterval(() => setLead(i => (i + 1) % window.ESK.lanes.length), 3200);
    return () => clearInterval(t);
  }, [paused, committed]);
  const steps = window.ESK.steps.map((s, i) => committed && i === window.ESK.steps.length - 1 ? {
    title: 'PO-2291 issued',
    value: '$18,240'
  } : s);
  return /*#__PURE__*/React.createElement("div", {
    className: "esk-workspace"
  }, /*#__PURE__*/React.createElement(StageModule, {
    title: committed ? 'PO-2291 issued to Meridian Supply' : 'Comparing 14 vendor quotes',
    subtitle: committed ? 'Confirmed 4 seconds ago · delivery 12 Mar' : 'Brake rotors · 480 units · delivery by 12 Mar',
    state: paused ? 'attention' : 'active',
    committed: committed,
    lanes: committed ? [] : window.ESK.lanes,
    leadIndex: lead,
    onInterrupt: committed ? undefined : () => setPaused(p => !p),
    footer: committed ? /*#__PURE__*/React.createElement(StatusDot, {
      state: "success",
      label: "Locked in \u2014 this cannot be undone"
    }) : /*#__PURE__*/React.createElement(StatusDot, {
      state: paused ? 'attention' : 'active',
      pulse: true,
      label: paused ? 'Paused — waiting on you' : `Evaluating ${window.ESK.lanes[lead].title}`
    })
  }, committed ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-10)',
      marginTop: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement(DataValue, {
    label: "Landed total",
    prefix: "$",
    value: "18,240",
    size: "xl"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Unit price",
    prefix: "$",
    value: "38.00",
    size: "xl"
  }), /*#__PURE__*/React.createElement(DataValue, {
    label: "Lead time",
    value: "6",
    unit: "days",
    size: "xl"
  })) : null), /*#__PURE__*/React.createElement("div", {
    className: "esk-strip-head"
  }, /*#__PURE__*/React.createElement(MicroLabel, null, "Resolved steps"), !committed ? /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    icon: "check",
    onClick: () => setConfirm(true)
  }, "Award to Meridian") : null), /*#__PURE__*/React.createElement(StepFilmstrip, {
    steps: steps
  }), /*#__PURE__*/React.createElement(Surface, {
    material: "panel",
    z: 1,
    className: "esk-note"
  }, /*#__PURE__*/React.createElement(MicroLabel, null, "Next stage"), /*#__PURE__*/React.createElement("p", {
    className: "es-body",
    style: {
      marginTop: 6
    }
  }, "Once awarded, Everstock issues the PO, files it against the open requisition and watches the vendor inbox for an acknowledgement. You will only hear from it again if something needs you.")), /*#__PURE__*/React.createElement(Dialog, {
    open: confirm,
    title: "Award to Meridian Supply?",
    description: "PO-2291 \xB7 480 units \xB7 $18,240 landed. Issuing the order is a committed action and cannot be undone.",
    onClose: () => setConfirm(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setConfirm(false)
    }, "Keep comparing"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "lock",
      onClick: () => {
        setConfirm(false);
        setCommitted(true);
        setToast(true);
      }
    }, "Issue PO"))
  }), toast ? /*#__PURE__*/React.createElement("div", {
    className: "esk-toasts"
  }, /*#__PURE__*/React.createElement(Toast, {
    state: "success",
    title: "PO-2291 issued",
    description: "Meridian Supply acknowledged in 40 seconds.",
    onClose: () => setToast(false)
  })) : null);
}
Object.assign(window, {
  Workspace
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/Workspace.jsx", error: String((e && e.message) || e) }); }

// ui_kits/everstock-app/data.js
try { (() => {
window.ESK = {
  nav: [{
    id: 'hub',
    icon: 'layout-grid',
    label: 'Command hub'
  }, {
    id: 'workspace',
    icon: 'bot',
    label: 'Agent workspace'
  }, {
    id: 'quotes',
    icon: 'file-text',
    label: 'Quotes'
  }, {
    id: 'orders',
    icon: 'receipt',
    label: 'Orders & invoices'
  }, {
    id: 'connections',
    icon: 'plug',
    label: 'Connections'
  }],
  tiles: [{
    id: 'quotes',
    icon: 'file-text',
    title: 'Quotes',
    state: 'active',
    meta: '3 vendors responding',
    preview: [{
      label: 'Meridian Supply',
      value: '$18,240'
    }, {
      label: 'Northline Parts',
      value: '$18,905'
    }, {
      label: 'Delta Components',
      value: '$17,860'
    }]
  }, {
    id: 'orders',
    icon: 'receipt',
    title: 'Purchase orders',
    state: 'success',
    meta: '2 issued today',
    preview: [{
      label: 'PO-2291',
      value: '$18,240'
    }, {
      label: 'PO-2290',
      value: '$4,120'
    }]
  }, {
    id: 'invoices',
    icon: 'circle-dollar-sign',
    title: 'Invoices',
    state: 'attention',
    meta: '2 need approval',
    preview: [{
      label: 'INV-4417',
      value: '$6,300'
    }, {
      label: 'INV-4418',
      value: '$1,145'
    }]
  }, {
    id: 'email',
    icon: 'mail',
    title: 'Email drafts',
    state: 'attention',
    meta: '1 awaiting your send',
    preview: [{
      label: 'Re: rotor pricing',
      value: 'draft'
    }, {
      label: 'Q3 blanket order',
      value: 'draft'
    }]
  }, {
    id: 'schedules',
    icon: 'calendar',
    title: 'Schedules',
    state: 'idle',
    meta: 'Next run 06:00',
    preview: [{
      label: 'Reorder sweep',
      value: 'daily'
    }, {
      label: 'Vendor scorecard',
      value: 'weekly'
    }]
  }, {
    id: 'connections',
    icon: 'plug',
    title: 'Connections',
    state: 'alert',
    category: 'infra',
    meta: '1 credential expired',
    preview: [{
      label: 'NetSuite',
      value: 'ok'
    }, {
      label: 'Vendor portal · TRW',
      value: 'expired',
      state: 'alert'
    }]
  }],
  lanes: [{
    id: 'v1',
    kicker: 'Vendor 01',
    title: 'Meridian Supply',
    rows: [{
      label: 'Unit',
      value: '$38.00'
    }, {
      label: 'Freight',
      value: '$2.10'
    }, {
      label: 'Lead',
      value: '6 d'
    }, {
      label: 'Landed',
      value: '$18,240'
    }]
  }, {
    id: 'v2',
    kicker: 'Vendor 02',
    title: 'Northline Parts',
    rows: [{
      label: 'Unit',
      value: '$39.40'
    }, {
      label: 'Freight',
      value: '$0.00'
    }, {
      label: 'Lead',
      value: '4 d'
    }, {
      label: 'Landed',
      value: '$18,905'
    }]
  }, {
    id: 'v3',
    kicker: 'Vendor 03',
    title: 'Delta Components',
    rows: [{
      label: 'Unit',
      value: '$37.15'
    }, {
      label: 'Freight',
      value: '$4.05'
    }, {
      label: 'Lead',
      value: '11 d'
    }, {
      label: 'Landed',
      value: '$19,776'
    }]
  }, {
    id: 'v4',
    kicker: 'Vendor 04',
    title: 'Halden Industrial',
    rows: [{
      label: 'Unit',
      value: '$38.90'
    }, {
      label: 'Freight',
      value: '$1.40'
    }, {
      label: 'Lead',
      value: '7 d'
    }, {
      label: 'Landed',
      value: '$19,344'
    }]
  }],
  steps: [{
    title: 'Demand parsed',
    value: '480 units'
  }, {
    title: 'Vendors matched',
    value: '14 vendors'
  }, {
    title: 'RFQs sent',
    value: '14 sent'
  }, {
    title: 'Quotes returned',
    value: '11 of 14'
  }, {
    title: 'Award & issue PO',
    pending: true
  }],
  quotes: [{
    id: 'q1',
    vendor: 'Meridian Supply',
    part: 'BRK-4471-XL',
    desc: 'Vented brake rotor, 330mm',
    unit: '38.00',
    qty: '480',
    lead: '6',
    landed: '18,240',
    state: 'success',
    status: 'Best landed'
  }, {
    id: 'q2',
    vendor: 'Northline Parts',
    part: 'BRK-4471-XL',
    desc: 'Vented brake rotor, 330mm',
    unit: '39.40',
    qty: '480',
    lead: '4',
    landed: '18,905',
    state: 'active',
    status: 'Negotiating'
  }, {
    id: 'q3',
    vendor: 'Delta Components',
    part: 'BRK-4471-XL',
    desc: 'Vented brake rotor, 330mm',
    unit: '37.15',
    qty: '400',
    lead: '11',
    landed: '19,776',
    state: 'attention',
    status: 'Short qty'
  }, {
    id: 'q4',
    vendor: 'Halden Industrial',
    part: 'BRK-4471-XL',
    desc: 'Vented brake rotor, 330mm',
    unit: '38.90',
    qty: '480',
    lead: '7',
    landed: '19,344',
    state: 'idle',
    status: 'Received'
  }, {
    id: 'q5',
    vendor: 'Kestrel Electronics',
    part: 'CN-1108-D',
    desc: 'Board-to-board connector, 40p',
    unit: '2.14',
    qty: '12,000',
    lead: '18',
    landed: '26,880',
    state: 'active',
    status: 'Negotiating'
  }, {
    id: 'q6',
    vendor: 'Arcline Components',
    part: 'CN-1108-D',
    desc: 'Board-to-board connector, 40p',
    unit: '2.31',
    qty: '12,000',
    lead: '9',
    landed: '28,344',
    state: 'idle',
    status: 'Received'
  }, {
    id: 'q7',
    vendor: 'Volta Distribution',
    part: 'MCU-33F-QFN',
    desc: '32-bit MCU, QFN-48',
    unit: '4.86',
    qty: '5,000',
    lead: '22',
    landed: '24,300',
    state: 'alert',
    status: 'No stock'
  }],
  orders: [{
    id: 'PO-2291',
    vendor: 'Meridian Supply',
    items: '480',
    total: '18,240',
    issued: '2026-03-04',
    eta: '2026-03-12',
    state: 'success',
    status: 'Issued'
  }, {
    id: 'PO-2290',
    vendor: 'Kestrel Electronics',
    items: '12,000',
    total: '26,880',
    issued: '2026-03-04',
    eta: '2026-03-26',
    state: 'success',
    status: 'Issued'
  }, {
    id: 'PO-2289',
    vendor: 'Halden Industrial',
    items: '240',
    total: '9,336',
    issued: '2026-03-02',
    eta: '2026-03-09',
    state: 'active',
    status: 'In transit'
  }, {
    id: 'PO-2287',
    vendor: 'Arcline Components',
    items: '6,000',
    total: '13,860',
    issued: '2026-02-27',
    eta: '2026-03-08',
    state: 'attention',
    status: 'Partial'
  }, {
    id: 'PO-2284',
    vendor: 'Delta Components',
    items: '400',
    total: '14,860',
    issued: '2026-02-24',
    eta: '2026-03-01',
    state: 'alert',
    status: 'Late'
  }],
  invoices: [{
    id: 'INV-4417',
    vendor: 'Meridian Supply',
    po: 'PO-2291',
    total: '6,300',
    due: '2026-03-18',
    state: 'attention',
    status: 'Needs approval'
  }, {
    id: 'INV-4418',
    vendor: 'Kestrel Electronics',
    po: 'PO-2290',
    total: '1,145',
    due: '2026-03-20',
    state: 'attention',
    status: 'Needs approval'
  }, {
    id: 'INV-4411',
    vendor: 'Halden Industrial',
    po: 'PO-2289',
    total: '9,336',
    due: '2026-03-11',
    state: 'success',
    status: 'Paid'
  }, {
    id: 'INV-4402',
    vendor: 'Arcline Components',
    po: 'PO-2287',
    total: '13,860',
    due: '2026-03-05',
    state: 'alert',
    status: 'Overdue'
  }],
  connections: [{
    id: 'netsuite',
    icon: 'building-2',
    name: 'NetSuite',
    kind: 'ERP',
    state: 'success',
    detail: 'Synced 4 minutes ago',
    on: true
  }, {
    id: 'trw',
    icon: 'truck',
    name: 'TRW vendor portal',
    kind: 'Vendor portal',
    state: 'alert',
    detail: 'Credential expired 2 days ago',
    on: true
  }, {
    id: 'mail',
    icon: 'mail',
    name: 'Procurement inbox',
    kind: 'Email',
    state: 'active',
    detail: 'Watching 3 threads',
    on: true
  }, {
    id: 'edi',
    icon: 'link',
    name: 'EDI 850 / 855',
    kind: 'Transport',
    state: 'success',
    detail: '212 documents this month',
    on: true
  }, {
    id: 'wms',
    icon: 'package',
    name: 'Warehouse counts',
    kind: 'Inventory',
    state: 'idle',
    detail: 'Not connected',
    on: false
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/everstock-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Identity = __ds_scope.Identity;

__ds_ns.SheenText = __ds_scope.SheenText;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ThemeToggle = __ds_scope.ThemeToggle;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.DataValue = __ds_scope.DataValue;

__ds_ns.MicroLabel = __ds_scope.MicroLabel;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

__ds_ns.StatusDot = __ds_scope.StatusDot;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.HubTile = __ds_scope.HubTile;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.BeamField = __ds_scope.BeamField;

__ds_ns.ComparisonRail = __ds_scope.ComparisonRail;

__ds_ns.FloatingInput = __ds_scope.FloatingInput;

__ds_ns.StageFlow = __ds_scope.StageFlow;

__ds_ns.StageModule = __ds_scope.StageModule;

__ds_ns.StepFilmstrip = __ds_scope.StepFilmstrip;

__ds_ns.StepIndicator = __ds_scope.StepIndicator;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Surface = __ds_scope.Surface;

})();

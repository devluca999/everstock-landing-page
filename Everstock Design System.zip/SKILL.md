---
name: everstock-design
description: Use this skill to generate well-branded interfaces and assets for Everstock, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Non-negotiables for Everstock's product interface, before you write anything:

1. **Render dark AND light every pass.** Dark background is warm-neutral graphite `#16171B` — never navy. Light background is warm eggshell `#FAF7F1` — never `#FFFFFF`, never cool grey.
2. **No flat single-layer cards.** Every surface = base fill + matte pass + grain + reflective sheen + dual-stack shadow (ambient + key + inset top highlight). Use the `.es-surface` stack or the `Surface` component; never write your own single `box-shadow`.
3. **Material is semantic.** Frosted glass = active/ephemeral. Chrome/metallic = resolved/committed, rare, dark mode only.
4. **Colour is state, never category.** Blue working, amber needs input, green resolved, red human required. Category lives in the icon.
5. **Every figure is Geist Mono with tabular figures.** Prices, quantities, part numbers, lead times, PO/RFQ identifiers.
6. **Uppercase only in micro-labels.** Never a heading, button or badge.
7. **Everything must be legible with motion disabled.**

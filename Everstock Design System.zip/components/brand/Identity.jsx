import React from 'react';

/** Persistent identity anchor. Required on every screen, modal and expanded sub-environment. */
export function Identity({
  variant = 'anchored',
  theme = 'dark',
  size = 'md',
  showWordmark = true,
  fixed = false,
  href = '#',
  onClick,
  className = '',
  style,
  ...rest
}) {
  const base = (typeof window !== 'undefined' && window.ES_ASSET_BASE) || 'assets/';
  const markH = size === 'sm' ? 14 : size === 'lg' ? 24 : 18;
  // Below ~24px the display cut's 8 facet gaps fall under a device pixel and the form
  // fragments, so the small cut (5 chunkier facets) takes over. Same mark, tuned for scale.
  const cut = markH < 24 ? '-sm' : '';
  const wordSize = size === 'sm' ? 'var(--text-2xs)' : size === 'lg' ? 'var(--text-sm)' : 'var(--text-xs)';
  const cls = [
    'es-identity',
    variant === 'pill' ? 'es-identity-pill' : 'es-identity-anchored',
    fixed ? 'es-identity-fixed' : '',
    showWordmark ? '' : 'es-identity-mark-only',
    className
  ].filter(Boolean).join(' ');

  return (
    <a href={href} onClick={onClick} className={cls} aria-label="Everstock"
       style={{ '--identity-mark': markH + 'px', ...style }} {...rest}>
      <img src={`${base}logo-mark-${theme}${cut}.svg`} alt="" />
      {showWordmark ? <span className="es-wordmark es-sheen" style={{ fontSize: wordSize }}>Everstock</span> : null}
    </a>
  );
}

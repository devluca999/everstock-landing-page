export interface SheenTextProps {
  /** Element to render — pair with a type class, e.g. `as="h2" className="es-title"`. */
  as?: keyof JSX.IntrinsicElements;
  /** `full` is the wordmark/hero ramp; `soft` is the shallower ramp for smaller resolved headlines. */
  tone?: 'full' | 'soft';
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * The chrome material rendered as typography — off-white fading to matte asphalt in dark mode,
 * inverting in light. Reserved for RESOLVED/committed content (a locked step's headline, a
 * completed PO title) and for the wordmark. Two rules keep it meaningful: active/glass-state
 * headlines stay flat, and it is never set ON a chrome surface — that surface already carries
 * the material, and the gradient's dark half would fight the metal's bright bands.
 */
export declare function SheenText(props: SheenTextProps): JSX.Element;

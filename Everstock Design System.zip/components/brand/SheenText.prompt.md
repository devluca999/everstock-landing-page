The chrome material as typography — use it on resolved/committed headlines and the wordmark, never on active-state text and never on top of a chrome surface.

```jsx
<SheenText as="h2" className="es-title">PO-4471 issued</SheenText>
<SheenText as="span" tone="soft" className="es-subtitle">Quote locked</SheenText>
```

- `tone="full"` is the deep wordmark/hero ramp; `tone="soft"` is shallower, for subtitle-scale resolved headlines.
- **Background rule:** sheen text belongs on the field or a panel. On an actual chrome surface the headline stays flat `var(--chrome-text)` — the surface is already the material, and the gradient's dark half collides with the metal's bright bands.
- **State rule:** never on a headline inside a glass surface. Glass means active/ephemeral, and a sheened active headline destroys the signal.
- Inverts automatically with `[data-theme="light"]`; no props needed.

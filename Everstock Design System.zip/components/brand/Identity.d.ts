export interface IdentityProps {
  /** `anchored` sits flush in a rail or header; `pill` is the consolidated floating glass pill. */
  variant?: 'anchored' | 'pill';
  /** Which mark asset to use — must match the active theme. */
  theme?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg';
  /** Mark-only is permitted in a 56px rail; the wordmark must then appear elsewhere on screen. */
  showWordmark?: boolean;
  /** Fixes the anchor top-left over full-bleed environments that have no rail. */
  fixed?: boolean;
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * The persistent identity anchor. Everstock's mark and wordmark must be visible in a fixed
 * location on every screen, modal and expanded hub sub-environment — an orientation
 * requirement, not branding garnish. The wordmark carries the chrome sheen treatment.
 */
export declare function Identity(props: IdentityProps): JSX.Element;

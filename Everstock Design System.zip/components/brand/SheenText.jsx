import React from 'react';

/** Chrome-as-typography. Resolved/committed headlines and the wordmark only. */
export function SheenText({ as: Tag = 'span', tone = 'full', children, className = '', style, ...rest }) {
  const cls = ['es-sheen', tone === 'soft' ? 'es-sheen-soft' : '', className].filter(Boolean).join(' ');
  return <Tag className={cls} style={style} {...rest}>{children}</Tag>;
}

The persistent Everstock identity anchor — mark plus sheen wordmark — required in a fixed location on every screen, modal and expanded sub-environment.

```jsx
<Identity theme={theme} />
<Identity variant="pill" theme={theme} fixed />
<Identity theme={theme} size="sm" showWordmark={false} />
```

- `variant="anchored"` (default) sits flush in a rail or top bar; `variant="pill"` is the consolidated floating glass pill, modeled on the marketing nav's scroll behaviour.
- `fixed` pins it top-left over full-bleed environments (process frames, expanded hub tiles) that have no rail of their own.
- `theme` must track the active theme — it selects the light or dark mark asset.
- `showWordmark={false}` is only acceptable when the wordmark is visible somewhere else on the same screen.

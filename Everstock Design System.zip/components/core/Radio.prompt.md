# Radio

One-of-N choice within a named group.

~~~jsx
<Radio name="autonomy" label="Ask before every send" />
<Radio name="autonomy" label="Send, then notify" defaultChecked />
~~~

Give every member of a group the same name prop.

import React from 'react';

/** Switch for settings that take effect immediately (autonomy levels, notifications). */
export function Switch({ label, description, disabled = false, className = '', ...rest }) {
  return (
    <label className={['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' ')}
      style={{ alignItems: 'center', gap: 'var(--space-5)' }}>
      <input type="checkbox" role="switch" disabled={disabled} {...rest} />
      <span className="es-switch" />
      <span>
        {label}
        {description ? <span style={{ display: 'block', color: 'var(--text-faint)', fontSize: 'var(--text-2xs)' }}>{description}</span> : null}
      </span>
    </label>
  );
}

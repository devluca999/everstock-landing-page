import type { InputHTMLAttributes } from 'react';
export interface RadioProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
}
export declare function Radio(props: RadioProps): JSX.Element;

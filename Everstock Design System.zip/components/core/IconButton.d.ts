import type { ButtonHTMLAttributes } from 'react';
export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Lucide icon name. */
  icon: string;
  /** Required — becomes the accessible name and the title attribute. */
  label: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'ghost' | 'bordered';
  /** Renders the state-active treatment for toggled toolbar buttons. */
  active?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;

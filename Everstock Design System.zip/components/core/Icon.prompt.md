# Icon

Renders a Lucide glyph masked with currentColor — use it for every icon in the system; never hand-roll an SVG or reach for emoji.

~~~jsx
<Icon name="truck" size={16} />
<Icon name="circle-check" size={20} title="Resolved" />
~~~

Icons live in assets/icons as raw Lucide SVGs. Set window.ES_ICON_BASE if your page sits at a different depth (e.g. "../../assets/icons/"). Default stroke weight is Lucide 2px at 24px — do not mix icon sets.

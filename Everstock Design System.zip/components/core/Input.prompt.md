# Input

Text or numeric field with the recessed-well treatment; set mono for anything numeric so figures stay tabular.

~~~jsx
<Input label="Part number" icon="hash" placeholder="BRK-4471-XL" mono />
<Input label="Target unit price" prefix mono defaultValue="184.50" />
<Input label="Notes" multiline rows={3} />
~~~

label renders as a micro-label (the only uppercase role in the system). error flips the field to aria-invalid and shows a red hint.

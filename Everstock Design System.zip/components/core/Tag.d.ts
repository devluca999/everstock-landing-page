import type { ReactNode, HTMLAttributes } from 'react';
export interface TagProps extends HTMLAttributes<HTMLSpanElement> {
  /** Monospace + tabular figures — use for SKUs, PO numbers, part identifiers. */
  mono?: boolean;
  selected?: boolean;
  /** Renders a remove affordance. */
  onRemove?: () => void;
  icon?: string;
  children?: ReactNode;
}
export declare function Tag(props: TagProps): JSX.Element;

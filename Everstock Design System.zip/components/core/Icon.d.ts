import type { CSSProperties } from 'react';
export interface IconProps {
  /** Lucide icon file name, e.g. "package", "truck", "circle-check". */
  name: string;
  /** Square size in px. Defaults to 16. */
  size?: number;
  /** Accessible name. Omit for purely decorative glyphs. */
  title?: string;
  className?: string;
  style?: CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;

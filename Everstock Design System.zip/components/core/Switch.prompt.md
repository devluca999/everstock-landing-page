# Switch

Setting that takes effect the moment it is flipped.

~~~jsx
<Switch label="Auto-escalate on no reply" description="After 48 hours" defaultChecked />
~~~

Do not use for form fields that need a save step — use Checkbox there.

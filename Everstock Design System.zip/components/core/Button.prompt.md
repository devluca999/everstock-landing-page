# Button

The system button — use secondary by default, primary for the single most important action on a surface, and chrome only for an action that is already committed and cannot be undone.

~~~jsx
<Button variant="primary" icon="send">Send RFQ</Button>
<Button variant="secondary">Review quotes</Button>
<Button variant="chrome" icon="lock">PO issued</Button>
<Button variant="ghost" size="sm">Cancel</Button>
~~~

Variants: primary, secondary, glass, chrome, ghost, danger. Sizes sm (26px), md (32px), lg (40px). Never uppercase a button label. Loading swaps the leading icon for a spinner and disables the control.

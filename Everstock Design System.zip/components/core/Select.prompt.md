# Select

Native select wearing Everstock control chrome — for short, known option sets.

~~~jsx
<Select label="Route to" options={[{value:"auto",label:"Auto-approve"},{value:"review",label:"Human review"}]} />
~~~

Options are {value,label}. For long lists prefer a searchable pattern built on Input rather than stretching this component.

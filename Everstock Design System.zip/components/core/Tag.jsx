import React from 'react';
import { Icon } from './Icon.jsx';

/** Neutral chip for CATEGORY, filter or identifier. Never carries state colour — use StatusBadge for that. */
export function Tag({ mono = false, selected = false, onRemove, icon, className = '', children, ...rest }) {
  const cls = [
    'es-tag', mono ? 'es-tag-mono' : '', selected ? 'es-tag-selected' : '',
    onRemove ? 'es-tag-removable' : '', className
  ].filter(Boolean).join(' ');
  return (
    <span className={cls} {...rest}>
      {icon ? <Icon name={icon} size={11} /> : null}
      {children}
      {onRemove ? (
        <button type="button" className="es-tag-x" aria-label="Remove" onClick={onRemove}>
          <Icon name="x" size={10} />
        </button>
      ) : null}
    </span>
  );
}

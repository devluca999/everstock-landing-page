import React from 'react';

/** Radio for one-of-N choices. Pass the same `name` to every member of a group. */
export function Radio({ label, description, disabled = false, className = '', ...rest }) {
  return (
    <label className={['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' ')}>
      <input type="radio" disabled={disabled} {...rest} />
      <span className="es-box es-box-round"><span className="es-box-dot" /></span>
      <span>
        {label}
        {description ? <span style={{ display: 'block', color: 'var(--text-faint)', fontSize: 'var(--text-2xs)' }}>{description}</span> : null}
      </span>
    </label>
  );
}

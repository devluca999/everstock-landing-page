import React from 'react';
import { Icon } from './Icon.jsx';

/** Everstock button. `chrome` is reserved for committed/executed actions — use it sparingly. */
export function Button({
  variant = 'secondary', size = 'md', icon, iconRight, loading = false,
  block = false, disabled = false, className = '', children, ...rest
}) {
  const cls = [
    'es-btn', `es-btn-${variant}`,
    size !== 'md' ? `es-btn-${size}` : '',
    block ? 'es-btn-block' : '', className
  ].filter(Boolean).join(' ');
  const gl = size === 'lg' ? 16 : size === 'sm' ? 13 : 14;
  return (
    <button className={cls} disabled={disabled || loading} {...rest}>
      {loading ? <span className="es-btn-spin" /> : icon ? <Icon name={icon} size={gl} /> : null}
      <span>{children}</span>
      {iconRight ? <Icon name={iconRight} size={gl} /> : null}
    </button>
  );
}

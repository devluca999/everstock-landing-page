# Tag

Neutral chip for a category, filter or identifier. It never carries state colour.

~~~jsx
<Tag mono>PO-2291-B</Tag>
<Tag icon="building-2">Preferred vendor</Tag>
<Tag selected onRemove={clear}>Lead time under 7 days</Tag>
~~~

If you are about to colour a Tag to show status, use StatusBadge instead — hue is reserved for state.

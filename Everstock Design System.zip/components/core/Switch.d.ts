import type { InputHTMLAttributes } from 'react';
export interface SwitchProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
}
export declare function Switch(props: SwitchProps): JSX.Element;

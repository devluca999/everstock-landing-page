# Checkbox

Multi-select toggle for filters and batch selection.

~~~jsx
<Checkbox label="Only vendors with stock on hand" />
<Checkbox label="Include freight" description="Adds landed cost to every comparison" defaultChecked />
~~~

Pairs with Radio and Switch — same choice chrome, different semantics. Switch is for settings that apply instantly; Checkbox is for selections you submit.

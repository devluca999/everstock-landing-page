import type { InputHTMLAttributes } from 'react';
export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  /** Rendered as a micro-label (uppercase) above the field. */
  label?: string;
  hint?: string;
  /** Error message; also flips the field to aria-invalid. */
  error?: string;
  /** Lucide icon name rendered inside the field. */
  icon?: string;
  size?: 'sm' | 'md' | 'lg';
  /** Monospace + tabular figures. Required for any numeric or identifier entry. */
  mono?: boolean;
  multiline?: boolean;
}
export declare function Input(props: InputProps): JSX.Element;

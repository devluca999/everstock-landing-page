export interface ThemeToggleProps {
  /** Controlled value. Omit to let the component own its state. */
  value?: 'dark' | 'light';
  onChange?: (theme: 'dark' | 'light') => void;
  /** Element to write data-theme onto. Defaults to document.documentElement. */
  target?: HTMLElement | null;
  className?: string;
}
export declare function ThemeToggle(props: ThemeToggleProps): JSX.Element;

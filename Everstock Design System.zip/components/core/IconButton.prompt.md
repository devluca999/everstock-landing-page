# IconButton

Square icon-only control for toolbars, table row actions and panel headers.

~~~jsx
<IconButton icon="funnel" label="Filter" />
<IconButton icon="panel-left" label="Toggle sidebar" variant="bordered" />
<IconButton icon="list" label="List view" active />
~~~

label is mandatory. Use variant="bordered" when the button sits directly on the beam field rather than inside a surface.

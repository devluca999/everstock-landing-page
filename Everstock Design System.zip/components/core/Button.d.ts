import type { ReactNode, ButtonHTMLAttributes } from 'react';
/**
 * Everstock button.
 */
export interface ButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  /** chrome = a committed / executed action. Use it rarely and only for resolved states. */
  variant?: 'primary' | 'secondary' | 'glass' | 'chrome' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  /** Lucide icon name shown before the label. */
  icon?: string;
  /** Lucide icon name shown after the label. */
  iconRight?: string;
  loading?: boolean;
  block?: boolean;
  children?: ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;

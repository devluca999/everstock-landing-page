import type { InputHTMLAttributes } from 'react';
export interface CheckboxProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  description?: string;
}
export declare function Checkbox(props: CheckboxProps): JSX.Element;

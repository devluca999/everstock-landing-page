import React from 'react';
import { Icon } from './Icon.jsx';

/** Checkbox with the recessed-well box treatment. */
export function Checkbox({ label, description, disabled = false, className = '', ...rest }) {
  return (
    <label className={['es-choice', disabled ? 'es-choice-disabled' : '', className].filter(Boolean).join(' ')}>
      <input type="checkbox" disabled={disabled} {...rest} />
      <span className="es-box"><Icon name="check" size={11} /></span>
      <span>
        {label}
        {description ? <span style={{ display: 'block', color: 'var(--text-faint)', fontSize: 'var(--text-2xs)' }}>{description}</span> : null}
      </span>
    </label>
  );
}

import React from 'react';
import { Icon } from './Icon.jsx';

/** Square icon-only control. `label` is required — it becomes the accessible name. */
export function IconButton({ icon, label, size = 'md', variant = 'ghost', active = false, className = '', ...rest }) {
  const cls = [
    'es-iconbtn',
    size !== 'md' ? `es-iconbtn-${size}` : '',
    variant === 'bordered' ? 'es-iconbtn-bordered' : '',
    active ? 'es-iconbtn-active' : '', className
  ].filter(Boolean).join(' ');
  return (
    <button className={cls} aria-label={label} title={label} {...rest}>
      <Icon name={icon} size={size === 'lg' ? 18 : size === 'sm' ? 13 : 15} />
    </button>
  );
}

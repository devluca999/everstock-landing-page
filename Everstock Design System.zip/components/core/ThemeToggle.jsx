import React from 'react';
import { Icon } from './Icon.jsx';

/** Dark/light switcher. Writes data-theme onto the given root (defaults to <html>). */
export function ThemeToggle({ value, onChange, target, className = '' }) {
  const [internal, setInternal] = React.useState(value || 'dark');
  const theme = value || internal;
  const set = (t) => {
    const el = target || (typeof document !== 'undefined' ? document.documentElement : null);
    if (el) el.setAttribute('data-theme', t);
    setInternal(t);
    if (onChange) onChange(t);
  };
  React.useEffect(() => { set(theme); /* eslint-disable-next-line */ }, [value]);
  return (
    <div className={['es-themetoggle', className].filter(Boolean).join(' ')} role="group" aria-label="Colour theme">
      <button type="button" aria-pressed={theme === 'dark'} onClick={() => set('dark')}>
        <Icon name="moon" size={12} />Dark
      </button>
      <button type="button" aria-pressed={theme === 'light'} onClick={() => set('light')}>
        <Icon name="sun" size={12} />Light
      </button>
    </div>
  );
}

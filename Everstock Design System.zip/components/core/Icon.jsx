import React from 'react';

const cache = new Map();

/** Lucide glyph, inlined so it inherits currentColor. Set window.ES_ICON_BASE to relocate the SVG folder. */
export function Icon({ name, size = 16, className = '', style, title, ...rest }) {
  const base = (typeof window !== 'undefined' && window.ES_ICON_BASE) || 'assets/icons/';
  const url = base + name + '.svg';
  const [markup, setMarkup] = React.useState(() => cache.get(url) || null);

  React.useEffect(() => {
    let live = true;
    if (cache.has(url)) { setMarkup(cache.get(url)); return; }
    fetch(url).then(r => r.ok ? r.text() : '').then(t => {
      const inner = t.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>[\s\S]*$/, '');
      cache.set(url, inner);
      if (live) setMarkup(inner);
    }).catch(() => {});
    return () => { live = false; };
  }, [url]);

  return (
    <svg
      className={('es-icon-svg ' + className).trim()}
      width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      role={title ? 'img' : undefined} aria-label={title} aria-hidden={title ? undefined : 'true'}
      style={{ flex: 'none', display: 'block', ...style }}
      dangerouslySetInnerHTML={{ __html: markup || '' }}
      {...rest}
    />
  );
}

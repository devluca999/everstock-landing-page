import React from 'react';
import { Icon } from './Icon.jsx';

/** Native select wearing Everstock control chrome. Options are {value,label}. */
export function Select({ label, hint, options = [], size = 'md', id, className = '', ...rest }) {
  const uid = id || React.useId();
  const cls = ['es-control', size !== 'md' ? `es-control-${size}` : '', className].filter(Boolean).join(' ');
  return (
    <div className="es-field-row">
      {label ? <label className="es-micro" htmlFor={uid}>{label}</label> : null}
      <div style={{ position: 'relative' }}>
        <select id={uid} className={cls} style={{ appearance: 'none', paddingRight: 28 }} {...rest}>
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <Icon name="chevron-down" size={14} style={{
          position: 'absolute', right: 9, top: '50%', transform: 'translateY(-50%)',
          color: 'var(--text-faint)', pointerEvents: 'none'
        }} />
      </div>
      {hint ? <p className="es-hint">{hint}</p> : null}
    </div>
  );
}

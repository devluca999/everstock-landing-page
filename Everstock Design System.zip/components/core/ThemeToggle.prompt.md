# ThemeToggle

Dark/light switcher. Light mode is a required deliverable, not an optional extra — ship it on every screen.

~~~jsx
<ThemeToggle onChange={(t)=>console.log(t)} />
~~~

Writes data-theme="dark" or "light" onto document.documentElement by default; pass target to scope it to a preview frame.

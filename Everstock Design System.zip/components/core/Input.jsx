import React from 'react';
import { Icon } from './Icon.jsx';

/** Text field. Set mono for any numeric / identifier entry so figures stay tabular. */
export function Input({
  label, hint, error, icon, size = 'md', mono = false, multiline = false,
  id, className = '', ...rest
}) {
  const uid = id || React.useId();
  const cls = [
    'es-control',
    size !== 'md' ? `es-control-${size}` : '',
    mono ? 'es-control-mono' : '',
    icon ? 'es-control-hasicon' : '', className
  ].filter(Boolean).join(' ');
  const Tag = multiline ? 'textarea' : 'input';
  return (
    <div className="es-field-row">
      {label ? <label className="es-micro" htmlFor={uid}>{label}</label> : null}
      <div style={{ position: 'relative' }}>
        {icon ? (
          <Icon name={icon} size={14} style={{
            position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)',
            color: 'var(--text-faint)', pointerEvents: 'none'
          }} />
        ) : null}
        <Tag id={uid} className={cls} aria-invalid={error ? 'true' : undefined}
          style={icon ? { paddingLeft: 30 } : undefined} {...rest} />
      </div>
      {error ? <p className="es-hint es-hint-error">{error}</p>
        : hint ? <p className="es-hint">{hint}</p> : null}
    </div>
  );
}

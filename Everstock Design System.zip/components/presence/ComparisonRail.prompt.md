The horizontal-scroll affordance for a comparison strip — a thin glass rail, segmented one tick per item, replacing the browser scrollbar.

```jsx
const lanes = React.useRef(null);
<div className="es-stage-lanes" ref={lanes}>…14 vendor cards…</div>
<ComparisonRail count={14} index={2} visible={4} label="Vendor quotes" scrollRef={lanes} />
```

- **Segmented by default** where there is a natural discrete count (≤40 items); above that it falls back to a continuous thumb.
- Ticks carry state: already-stepped-through items read green at low opacity, the visible range is the active blue marker, and `states` can flag an individual item amber or red.
- **Hover-reactive** — the rail lifts 1px and its ticks brighten; an individual tick grows on hover. Both disable under reduced motion, while position stays fully legible.
- Pair it with `.es-stage-lanes`, which suppresses its own scrollbar. Never re-enable the native one.

import React from 'react';
import { MicroLabel } from '../data/MicroLabel.jsx';

/**
 * The tray of resolved steps a center-stage module demotes into.
 * Resolved frames render in chrome; pending frames stay recessed and neutral.
 */
export function StepFilmstrip({ steps = [], className = '' }) {
  return (
    <div className={['es-filmstrip', className].filter(Boolean).join(' ')}>
      {steps.map((s, i) => (
        <article key={s.id ?? i} className={['es-frame', s.pending ? 'es-frame-pending' : ''].filter(Boolean).join(' ')}>
          <MicroLabel style={{ color: 'inherit', opacity: .7 }}>{s.pending ? 'Queued' : `Step ${i + 1}`}</MicroLabel>
          <p style={{ margin: '5px 0 0', fontSize: 'var(--text-xs)', fontWeight: 500, lineHeight: 1.3 }}>{s.title}</p>
          {s.value ? <p className="es-num" style={{ margin: '6px 0 0', fontSize: 'var(--text-2xs)', color: 'inherit', opacity: .85 }}>{s.value}</p> : null}
        </article>
      ))}
    </div>
  );
}

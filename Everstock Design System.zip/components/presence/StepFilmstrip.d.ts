export interface FilmstripStep {
  id?: string;
  title: string;
  value?: string;
  /** Not yet reached — renders recessed and neutral instead of chrome. */
  pending?: boolean;
}
export interface StepFilmstripProps {
  steps: FilmstripStep[];
  className?: string;
}
export declare function StepFilmstrip(props: StepFilmstripProps): JSX.Element;

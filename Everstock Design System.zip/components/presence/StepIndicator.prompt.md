The one sanctioned progress display — segmented, state-colored, one segment per real discrete step. Use it in stage headers, hub tiles and toolbars where a filmstrip is too big.

```jsx
<StepIndicator caption="Sourcing brake rotors" steps={[
  { label: 'Demand parsed', status: 'done' },
  { label: 'Vendors matched', status: 'done' },
  { label: 'RFQs sent', status: 'done' },
  { label: 'Comparing quotes', status: 'active' },
  { label: 'Award & PO' }
]} />
```

- **Never a percentage or a smooth fill.** If you cannot name each segment as a concrete step, this is the wrong component.
- Colors come from the state system only: `done` green, `active` blue + breathing, `attention` amber, `failed` red, pending is a recessed neutral well.
- `showLabels` is readable up to about 5 steps; beyond that rely on the tooltip and the caption count.
- Under reduced motion the active segment stops breathing but keeps its color and glow, so the state stays legible in a still frame.
- For the full narrative view of resolved steps, use `StepFilmstrip` instead — this is its compressed form.

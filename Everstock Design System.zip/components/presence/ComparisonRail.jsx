import React from 'react';

/**
 * The sanctioned horizontal-scroll affordance — a thin glass rail, segmented where the
 * content has a discrete count. Never a default browser scrollbar.
 */
export function ComparisonRail({
  count = 0, index = 0, visible = 1, states = [], label,
  onSeek, scrollRef, className = '', style, ...rest
}) {
  const segmented = count > 0 && count <= 40;

  const seek = (i) => {
    if (onSeek) return onSeek(i);
    const el = scrollRef && scrollRef.current;
    if (!el || !count) return;
    el.scrollTo({ left: (el.scrollWidth / count) * i, behavior: 'smooth' });
  };

  return (
    <div className={('es-crail-wrap ' + className).trim()} style={style} {...rest}>
      <div className="es-crail" role="group" aria-label={label || 'Scroll position'}>
        {segmented ? Array.from({ length: count }, (_, i) => {
          const s = states[i];
          const cls = ['es-crail-tick',
            s === 'attention' ? 'es-crail-tick-attention' : s === 'alert' ? 'es-crail-tick-alert' : '',
            i >= index && i < index + visible ? 'es-crail-tick-current' : i < index ? 'es-crail-tick-seen' : ''
          ].filter(Boolean).join(' ');
          return <button key={i} type="button" className={cls} aria-label={`Item ${i + 1} of ${count}`}
            aria-current={i === index || undefined} onClick={() => seek(i)} />;
        }) : (
          <span className="es-crail-thumb" style={{
            width: `${Math.max(8, (visible / Math.max(count, 1)) * 100)}%`,
            marginLeft: `${(index / Math.max(count, 1)) * 100}%`
          }} />
        )}
      </div>
      {count ? <span className="es-crail-count">{String(Math.min(index + visible, count)).padStart(2, '0')} / {count}</span> : null}
    </div>
  );
}

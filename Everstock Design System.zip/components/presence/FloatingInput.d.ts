/**
 * The persistent floating oval — part of the environment, never a modal or form field.
 */
export interface FloatingInputProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onSubmit?: (value: string | undefined) => void;
  /** Swaps the text field for a live waveform. */
  listening?: boolean;
  onToggleVoice?: () => void;
  className?: string;
}
export declare function FloatingInput(props: FloatingInputProps): JSX.Element;

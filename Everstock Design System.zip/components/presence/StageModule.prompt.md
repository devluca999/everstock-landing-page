# StageModule

The center-stage module — the agent's current unit of work with real material weight instead of a spinner or a percentage.

~~~jsx
<StageModule title="Comparing 14 vendor quotes" subtitle="Brake rotors, 480 units, delivery by 12 Mar" state="active" leadIndex={1}
  lanes={lanes} onInterrupt={pause} footer={<StatusDot state="active" pulse label="Evaluating Northline Parts" />} />
<StageModule title="PO-2291 issued" committed />
~~~

lanes are horizontal progressive disclosure — depth within one task. Vertical stacking is for moving between process stages. Setting committed swaps glass for chrome: the material event that says this is now real.

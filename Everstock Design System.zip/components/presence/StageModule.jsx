import React from 'react';
import { MicroLabel } from '../data/MicroLabel.jsx';
import { StatusBadge } from '../feedback/StatusBadge.jsx';
import { ComparisonRail } from './ComparisonRail.jsx';
import { StepIndicator } from './StepIndicator.jsx';

/**
 * Center-stage module: the agent's current unit of work, given real visual weight.
 * Never a percentage or spinner — progress, when shown, is the segmented StepIndicator.
 * Glass while working; switches to chrome the moment the step commits.
 * `lanes` are horizontal progressive disclosure — depth within one task.
 */
export function StageModule({
  title, subtitle, state = 'active', committed = false, lanes = [], leadIndex = 0,
  steps, railVisible = 4, railLabel, footer, onInterrupt, className = '', children
}) {
  const lanesRef = React.useRef(null);
  const [railIndex, setRailIndex] = React.useState(0);
  const showRail = lanes.length > railVisible;

  const seek = (i) => {
    setRailIndex(i);
    const el = lanesRef.current;
    if (el) el.scrollTo({ left: (el.scrollWidth / lanes.length) * i, behavior: 'smooth' });
  };

  const cls = [
    'es-stage',
    committed ? 'es-stage-committed' : state === 'attention' ? 'es-stage-attention' : state === 'alert' ? 'es-stage-alert' : '',
    className
  ].filter(Boolean).join(' ');
  return (
    <section className={cls}>
      <header style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 'var(--space-6)' }}>
        <div>
          <MicroLabel>{committed ? 'Committed' : 'Working now'}</MicroLabel>
          <h2 className="es-title" style={{ marginTop: 6, color: committed ? 'var(--chrome-text)' : undefined }}>{title}</h2>
          {subtitle ? <p className="es-body" style={{ marginTop: 6 }}>{subtitle}</p> : null}
        </div>
        <StatusBadge state={committed ? 'success' : state} pulse={!committed && state === 'active'}>
          {committed ? 'Locked in' : state === 'attention' ? 'Needs you' : state === 'alert' ? 'Blocked' : 'Live'}
        </StatusBadge>
      </header>
      {steps && steps.length ? (
        <StepIndicator steps={steps} className="" style={{ marginTop: 'var(--space-6)' }} />
      ) : null}
      {lanes.length ? (
        <div className="es-stage-lanes" ref={lanesRef} style={{ marginTop: 'var(--space-7)' }}>
          {lanes.map((l, i) => (
            <article key={l.id ?? i} className={['es-lane', i === leadIndex ? 'es-lane-lead' : ''].filter(Boolean).join(' ')}>
              <MicroLabel>{l.kicker}</MicroLabel>
              <p className="es-body" style={{ color: 'var(--text-primary)', marginTop: 5, fontWeight: 500 }}>{l.title}</p>
              <div style={{ display: 'grid', gap: 4, marginTop: 10 }}>
                {(l.rows || []).map((r, j) => (
                  <div key={j} style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                    <span className="es-caption">{r.label}</span>
                    <span className="es-num" style={{ fontSize: 'var(--text-xs)' }}>{r.value}</span>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      ) : null}
      {showRail ? (
        <ComparisonRail count={lanes.length} index={railIndex} visible={railVisible}
          label={railLabel || 'Comparison position'} onSeek={seek}
          style={{ marginTop: 'var(--space-5)' }} />
      ) : null}
      {children}
      {(footer || onInterrupt) ? (
        <footer style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-6)', marginTop: 'var(--space-7)' }}>
          <div style={{ display: 'flex', gap: 'var(--gap-inline)', alignItems: 'center' }}>{footer}</div>
          {onInterrupt ? (
            <button type="button" className="es-btn es-btn-ghost es-btn-sm" onClick={onInterrupt}><span>Interrupt</span></button>
          ) : null}
        </footer>
      ) : null}
    </section>
  );
}

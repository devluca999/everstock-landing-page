import type { ReactNode } from 'react';
import type { EverstockState } from '../feedback/StatusDot';
import type { StepIndicatorStep } from './StepIndicator';
export interface StageLaneRow { label: string; value: ReactNode }
export interface StageLane { id?: string; kicker: string; title: string; rows?: StageLaneRow[] }
/**
 * The agent's current unit of work, given real material weight instead of a progress bar.
 */
export interface StageModuleProps {
  title: string;
  subtitle?: string;
  state?: EverstockState;
  /** Switches the material from glass to chrome — the step is locked in. */
  committed?: boolean;
  /** Horizontal progressive disclosure: depth within one task. */
  lanes?: StageLane[];
  /** Index of the lane currently under evaluation. */
  leadIndex?: number;
  /** Segmented step indicator under the header. One segment per real discrete step, never a percentage. */
  steps?: StepIndicatorStep[];
  /** Lanes visible at once; above this a ComparisonRail replaces the native scrollbar. */
  railVisible?: number;
  /** Accessible label for that rail, e.g. "Vendor quotes". */
  railLabel?: string;
  footer?: ReactNode;
  /** Renders the always-available interrupt affordance. */
  onInterrupt?: () => void;
  className?: string;
  children?: ReactNode;
}
export declare function StageModule(props: StageModuleProps): JSX.Element;

# StepFilmstrip

The tray of resolved steps a stage module demotes into, sitting directly under the center stage.

~~~jsx
<StepFilmstrip steps={[{title:"Demand parsed",value:"480 units"},{title:"Vendors matched",value:"14"},{title:"Quotes requested",pending:true}]} />
~~~

Resolved frames render in chrome, pending frames stay recessed and neutral — the before/after is legible from a single still frame.

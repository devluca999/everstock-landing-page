# FloatingInput

The persistent floating oval, anchored bottom-center. Minimal at rest, expands on focus, shows a live waveform while listening.

~~~jsx
<FloatingInput value={q} onChange={setQ} onSubmit={run} listening={listening} onToggleVoice={toggle} />
~~~

It must never read as a modal or a form field — keep it floating over the field, never docked into a panel. Under reduced motion the waveform becomes a static level meter.

import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { IconButton } from '../core/IconButton.jsx';

/**
 * The persistent floating oval. Minimal at rest, expands on focus, shows a live
 * waveform while listening. Never reads as a modal or a form field.
 */
export function FloatingInput({
  placeholder = 'Tell Everstock what to do', value, onChange, onSubmit,
  listening = false, onToggleVoice, className = ''
}) {
  const [focused, setFocused] = React.useState(false);
  const bars = [6, 11, 16, 9, 14, 7, 12, 5];
  return (
    <form
      className={['es-oval', focused || listening ? 'es-oval-expanded' : '', className].filter(Boolean).join(' ')}
      style={{ width: focused || listening ? 520 : 380 }}
      onSubmit={(e) => { e.preventDefault(); if (onSubmit) onSubmit(value); }}
    >
      <Icon name="sparkles" size={14} style={{ color: focused ? 'var(--state-active)' : 'var(--text-faint)' }} />
      {listening ? (
        <span className="es-wave" style={{ flex: 1 }}>
          {bars.map((h, i) => (
            <span key={i} style={{ height: h, animation: `es-breathe ${900 + i * 110}ms ease-in-out infinite` }} />
          ))}
        </span>
      ) : (
        <input
          value={value} placeholder={placeholder}
          onChange={(e) => onChange && onChange(e.target.value)}
          onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        />
      )}
      <IconButton icon={listening ? 'pause' : 'mic'} label={listening ? 'Stop listening' : 'Speak'} onClick={onToggleVoice} type="button" />
      <IconButton icon="send" label="Send" variant="bordered" type="submit" />
    </form>
  );
}

export interface StepIndicatorStep {
  id?: string;
  /** The real step name — shown as a tooltip, and inline when `showLabels` is set. */
  label: string;
  /** Omit for pending. */
  status?: 'done' | 'active' | 'attention' | 'failed';
}

export interface StepIndicatorProps {
  steps: StepIndicatorStep[];
  /** Renders the step names under the bar. Only readable up to ~5 steps. */
  showLabels?: boolean;
  /** Adds a caption row with a `done / total` count. */
  caption?: string;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Segmented step indicator — the one sanctioned form of progress display. Every segment maps to
 * ONE real discrete step and takes its color from the state system: done is green, the active step
 * is blue and breathing, pending is a recessed neutral well, failed is red. Smooth or percentage
 * fills stay forbidden: they imply a precision an agent process does not have. This is the
 * step-filmstrip pattern compressed into a single bar for headers and tiles.
 */
export declare function StepIndicator(props: StepIndicatorProps): JSX.Element;

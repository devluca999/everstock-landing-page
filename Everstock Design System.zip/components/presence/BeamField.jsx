import React from 'react';

/**
 * Z-0 environment: the warm-graphite field, its grid, page-level grain and the traveling
 * beam particles. The GRID is the same on every screen — it is one persistent space the
 * product sits on, not a per-screen background — so only beam density varies by surface.
 * Beams are placed one per viewport region, never randomly: random placement visibly
 * clumps to one side. Particles are suppressed under reduced motion.
 */
export function BeamField({ density = 'standard', beams, className = '', style, children }) {
  // cols × rows of guaranteed coverage. Every region gets exactly one beam.
  const layout = { none: [0, 0], calm: [3, 1], standard: [4, 2], dense: [6, 2] }[density] || [4, 2];

  const list = React.useMemo(() => {
    if (beams) return beams;
    const [cols, rows] = layout;
    const out = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i = r * cols + c;
        // Deterministic jitter inside the region — spread, but never leaving its region.
        const jx = ((i * 37) % 100) / 100, jy = ((i * 53) % 100) / 100;
        out.push({
          left: `${((c + 0.16 + jx * 0.68) / cols) * 100}%`,
          top: `${((r + 0.10 + jy * 0.55) / rows) * 62}%`,
          hue: i % 3 === 2 ? 'var(--state-success)' : 'var(--state-active)',
          delay: `${((i * 0.83) % 3.6).toFixed(2)}s`,
          dur: `${(3.2 + (i % 4) * 0.9).toFixed(1)}s`
        });
      }
    }
    return out;
  }, [beams, density]);

  return (
    <div className={['es-field', className].filter(Boolean).join(' ')} style={style}>
      {list.length ? (
        <div aria-hidden="true" style={{ position: 'absolute', inset: 0, zIndex: 0, overflow: 'hidden', pointerEvents: 'none' }}>
          {list.map((b, i) => (
            <React.Fragment key={i}>
              <span className="es-beam-particle" style={{
                position: 'absolute', left: b.left, top: b.top, width: 1, height: 46,
                background: `linear-gradient(180deg, transparent, ${b.hue})`, opacity: .45,
                animation: `es-beam ${b.dur} linear ${b.delay} infinite`
              }} />
              <span className="es-beam-particle" style={{
                position: 'absolute', left: b.left, top: b.top, width: 3, height: 3, borderRadius: '50%',
                background: b.hue, boxShadow: `0 0 10px 1px ${b.hue}`,
                animation: `es-beam ${b.dur} linear ${b.delay} infinite`
              }} />
            </React.Fragment>
          ))}
        </div>
      ) : null}
      {children}
    </div>
  );
}

import React from 'react';

/** Segmented, state-colored step indicator. One segment = one real discrete step, never a percentage. */
export function StepIndicator({ steps = [], showLabels = false, caption, className = '', style, ...rest }) {
  const done = steps.filter(s => s.status === 'done').length;
  const failed = steps.some(s => s.status === 'failed');
  return (
    <div className={('es-steps ' + className).trim()} style={style} {...rest}
      role="group" aria-label={caption || `Step ${Math.min(done + 1, steps.length)} of ${steps.length}`}>
      <div className="es-steps-bar">
        {steps.map((s, i) => (
          <span key={s.id ?? i} className={['es-seg', s.status ? 'es-seg-' + s.status : ''].filter(Boolean).join(' ')}
            title={s.label} />
        ))}
      </div>
      {showLabels ? (
        <div className="es-steps-labels">
          {steps.map((s, i) => (
            <span key={s.id ?? i} className={['es-steps-label', s.status === 'active' || s.status === 'failed' ? 'es-steps-label-on' : ''].filter(Boolean).join(' ')}>{s.label}</span>
          ))}
        </div>
      ) : null}
      {caption !== undefined ? (
        <div className="es-steps-legend">
          <span className="es-caption">{caption}</span>
          <span className="es-num" style={{ fontSize: 'var(--text-2xs)', color: failed ? 'var(--state-alert)' : 'var(--text-faint)' }}>{done} / {steps.length}</span>
        </div>
      ) : null}
    </div>
  );
}

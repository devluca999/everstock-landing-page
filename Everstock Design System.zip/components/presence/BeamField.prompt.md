The Z-0 environment — grid, page grain and traveling beams. Wrap **every** screen in it, including calm ones.

```jsx
<BeamField density="dense">   {/* agent workspace */}
<BeamField density="standard">{/* command hub */}
<BeamField density="none">    {/* quotes, orders, connections — grid stays, beams stop */}
```

- **The grid is identical at every density.** It is one persistent space the whole product sits on; a screen that drops the grid breaks the "living environment" premise. Use `density="none"` for calm review surfaces rather than omitting the field.
- Beams are placed **one per viewport region** (a cols × rows partition with jitter inside each region). Never place them randomly — random placement visibly clumps to one side.
- `calm` 3×1 · `standard` 4×2 · `dense` 6×2. Light mode should step down one level.
- Particles disable under reduced motion; the grid and grain persist.

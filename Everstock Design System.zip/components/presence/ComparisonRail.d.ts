import type { EverstockState } from '../feedback/StatusDot';

export interface ComparisonRailProps {
  /** Total items in the strip. Drives the segment count. */
  count: number;
  /** Index of the first visible item. */
  index?: number;
  /** How many items are visible at once — widens the current marker. */
  visible?: number;
  /** Optional per-item state, so a rail tick can carry attention/alert. Index-aligned with the items. */
  states?: (EverstockState | undefined)[];
  /** Accessible group label, e.g. "Vendor quotes". */
  label?: string;
  /** Called with the target index when a tick is clicked. Falls back to scrolling `scrollRef`. */
  onSeek?: (index: number) => void;
  /** Ref to the scrolling element, used when `onSeek` is omitted. */
  scrollRef?: React.RefObject<HTMLElement>;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * The horizontal-scroll affordance for a comparison strip — a thin glass rail with a hairline
 * border and grain, hover-reactive rather than inert. With a natural discrete count (14 vendor
 * quotes) it renders one tick per item, so the rail expresses real state instead of a smooth
 * interpolated position; above 40 items it falls back to a continuous glowing thumb.
 * Native scrollbars are suppressed on `.es-stage-lanes` — this replaces them.
 */
export declare function ComparisonRail(props: ComparisonRailProps): JSX.Element;

import React from 'react';

/** Vertical stage flow — movement between distinct process stages (sourcing → quoting → approval). */
export function StageFlow({ stages = [], className = '', style, ...rest }) {
  return (
    <div className={('es-flow ' + className).trim()} style={style} {...rest}>
      {stages.map((s, i) => (
        <div key={s.id || i} className={'es-flow-row es-flow-' + (s.status || 'queued')}>
          <div className="es-flow-spine"><span className="es-flow-node" /></div>
          <div className="es-flow-panel">
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 'var(--space-6)' }}>
              <p className="es-subtitle" style={{ fontSize: 'var(--text-sm)', color: s.status === 'done' ? 'inherit' : undefined }}>{s.title}</p>
              {s.meta ? <span className="es-num" style={{ fontSize: 'var(--text-2xs)', color: 'inherit', opacity: .8 }}>{s.meta}</span> : null}
            </div>
            {s.detail ? <p style={{ margin: '5px 0 0', fontFamily: 'var(--font-ui)', fontSize: 'var(--text-xs)', lineHeight: 1.45, color: s.status === 'done' ? 'inherit' : 'var(--text-muted)', opacity: s.status === 'done' ? .82 : 1 }}>{s.detail}</p> : null}
          </div>
        </div>
      ))}
    </div>
  );
}

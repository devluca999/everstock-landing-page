export interface StageFlowStage {
  id?: string;
  title: string;
  /** Short right-aligned datum — set in the mono face, tabular figures. */
  meta?: string;
  detail?: string;
  /** `done` renders chrome + sheen headline, `live` renders glass + active glow, `queued` renders a dashed outline. */
  status?: 'done' | 'live' | 'queued';
}

export interface StageFlowProps {
  stages: StageFlowStage[];
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Vertical stacking = movement between distinct process stages (sourcing → quoting → approval),
 * as opposed to StageModule's horizontal lanes, which are depth within one task. Material carries
 * the state: resolved stages are chrome, the live stage is glass, queued stages are neither.
 */
export declare function StageFlow(props: StageFlowProps): JSX.Element;

Vertical stage transitions — movement between distinct process stages, where StageModule's horizontal lanes are depth within one task.

```jsx
<StageFlow stages={[
  { title: 'Sourcing', meta: '14 vendors', detail: 'Matched against the open requisition.', status: 'done' },
  { title: 'Quoting', meta: '11 of 14', detail: 'Comparing landed cost against lead time.', status: 'live' },
  { title: 'Approval', detail: 'Routes to you once a vendor is selected.', status: 'queued' }
]} />
```

- Material is the state signal: `done` is chrome with a sheened headline, `live` is glass with the active glow, `queued` is a dashed outline with no material at all.
- Exactly one stage should be `live` at a time.
- `meta` is always mono/tabular — counts, currency, lead times.

import type { ReactNode, CSSProperties } from 'react';

export interface Beam {
  left: string;
  top: string;
  hue: string;
  delay: string;
  dur: string;
}

export interface BeamFieldProps {
  /** Beam density only. The GRID is identical at every setting — it is one persistent space.
   *  `none` keeps the grid and drops every traveling particle (calm review surfaces). */
  density?: 'none' | 'calm' | 'standard' | 'dense';
  /** Explicit beam list, bypassing region placement. Rarely needed. */
  beams?: Beam[];
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
}

/**
 * The Z-0 environment: warm-graphite field, grid, page-level grain and traveling beams.
 * The grid renders identically on every screen so the product reads as one continuous space
 * rather than a series of separate backgrounds — only beam density changes by surface.
 * Beams are placed one per viewport region (cols × rows), never randomly, which is what
 * guarantees left/right and top/bottom coverage instead of clumping to one side.
 */
export declare function BeamField(props: BeamFieldProps): JSX.Element;

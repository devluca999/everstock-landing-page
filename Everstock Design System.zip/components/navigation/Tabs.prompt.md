# Tabs

Section switcher for calm review surfaces, with optional counts.

~~~jsx
<Tabs items={[{id:"open",label:"Open",count:14},{id:"awarded",label:"Awarded",count:6}]} onChange={setView} />
~~~

Counts render in Geist Mono so they stay tabular. The active indicator is a state-active hairline, not a filled pill.

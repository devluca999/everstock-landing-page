import type { EverstockState } from '../feedback/StatusDot';

export interface HubTilePreviewRow {
  label: string;
  value: string;
  /** Gives this row its own state color — the correct place for a real problem (an expired
   *  credential reads crimson HERE, never as a full-tile hover flare). */
  state?: EverstockState;
}

export interface HubTileProps {
  icon: string;
  title: string;
  /** Genuine content state. Drives the head dot; does NOT by itself drive the hover treatment. */
  state?: EverstockState;
  /** `infra` = infrastructure/management (Connections, Settings): indigo category identity. */
  category?: 'process' | 'infra';
  meta?: string;
  preview?: HubTilePreviewRow[];
  onOpen?: () => void;
  tilt?: boolean;
  className?: string;
}

/**
 * Command-hub bento tile. Hover defaults to a NEUTRAL material response — spotlight, chrome
 * shine, lift, tilt — because hovering must never imply state, least of all failure. Active,
 * attention and success tiles may tint that spotlight since they describe live process;
 * `alert` and `idle` deliberately do not. Infrastructure tiles carry the indigo category
 * accent as their ambient identity, and surface real problems as a crimson preview row.
 */
export declare function HubTile(props: HubTileProps): JSX.Element;

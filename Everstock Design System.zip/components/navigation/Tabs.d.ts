export interface TabItem { id: string; label: string; count?: number; icon?: string }
export interface TabsProps {
  items: TabItem[];
  /** Controlled selection. Omit to let the component own its state. */
  value?: string;
  onChange?: (id: string) => void;
  className?: string;
}
export declare function Tabs(props: TabsProps): JSX.Element;

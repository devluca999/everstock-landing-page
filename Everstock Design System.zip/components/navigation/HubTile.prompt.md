A command-hub bento tile with a live preview, a neutral material hover response, and Magic-Bento-style spotlight/tilt in Everstock's own language.

```jsx
<HubTile icon="file-text" title="Quotes" state="active" meta="3 vendors responding"
  preview={[{ label: 'Meridian Supply', value: '$18,240' }]} onOpen={…} />

<HubTile icon="plug" title="Connections" category="infra" state="alert" meta="1 credential expired"
  preview={[{ label: 'NetSuite', value: 'ok' },
            { label: 'Vendor portal · TRW', value: 'expired', state: 'alert' }]} onOpen={…} />
```

- **Hover never implies state.** Every tile gets the same neutral shine, lift and spotlight. `active` / `attention` / `success` may tint the spotlight because they describe live process; `alert` and `idle` fall back to neutral so hovering can't read as a failure flare.
- **A real problem lives in a preview row** with its own `state` — crimson on that line, not across the tile.
- `category="infra"` (Connections, Settings) swaps the ambient identity to the indigo category accent and tints the icon. Indigo is a category signal only, never a task state.
- `tilt={false}` where the tile sits on a dense lookup surface. Tilt and particles disable under reduced motion; the edge and dot stay.

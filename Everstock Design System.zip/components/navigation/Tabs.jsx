import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Underlined tabs for calm review surfaces. items: {id,label,count,icon}. */
export function Tabs({ items = [], value, onChange, className = '' }) {
  const [internal, setInternal] = React.useState(value ?? items[0]?.id);
  const active = value ?? internal;
  const pick = (id) => { setInternal(id); if (onChange) onChange(id); };
  return (
    <div className={['es-tabs', className].filter(Boolean).join(' ')} role="tablist">
      {items.map(it => (
        <button key={it.id} className="es-tab" role="tab" aria-selected={active === it.id} onClick={() => pick(it.id)}>
          {it.icon ? <Icon name={it.icon} size={13} /> : null}
          {it.label}
          {it.count != null ? <span className="es-tab-count">{it.count}</span> : null}
        </button>
      ))}
    </div>
  );
}

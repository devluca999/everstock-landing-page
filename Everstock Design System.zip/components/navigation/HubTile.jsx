import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { StatusDot } from '../feedback/StatusDot.jsx';

/**
 * Command-hub bento tile. Hover is a NEUTRAL material response by default — spotlight, shine,
 * lift and tilt — because hovering must never itself imply state, least of all failure. Only
 * genuine content carries state: the head dot, and any preview row given its own `state`.
 * Infrastructure tiles (`category="infra"`) carry the indigo category accent as their ambient
 * identity instead. Tilt + particles drop out under reduced motion.
 */
export function HubTile({
  icon, title, state = 'idle', category = 'process', meta, preview = [], onOpen, tilt = true, className = ''
}) {
  const ref = React.useRef(null);
  const [t, setT] = React.useState('');
  const move = (e) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    el.style.setProperty('--spot-x', `${px * 100}%`);
    el.style.setProperty('--spot-y', `${py * 100}%`);
    if (tilt) setT(`perspective(760px) rotateX(${(0.5 - py) * 6}deg) rotateY(${(px - 0.5) * 6}deg)`);
  };

  // Ambient identity ≠ state. Infrastructure is indigo; a live/awaiting process may tint its
  // own hover; alert and idle fall back to neutral so hover never reads as a failure flare.
  const ambient = category === 'infra' ? 'infra'
    : (state === 'active' || state === 'attention' || state === 'success') ? state
    : 'neutral';
  const vars = ambient === 'infra'
    ? { '--tile-glow': 'var(--accent-infra-wash)', '--tile-glow-solid': 'var(--accent-infra)', '--tile-edge': 'var(--accent-infra-edge)' }
    : ambient === 'neutral'
      ? { '--tile-glow': 'var(--tile-shine)', '--tile-glow-solid': 'var(--text-faint)', '--tile-edge': 'var(--line-strong)' }
      : { '--tile-glow': `var(--state-${ambient}-wash)`, '--tile-glow-solid': `var(--state-${ambient})`, '--tile-edge': `var(--state-${ambient}-edge)` };

  return (
    <button
      ref={ref} type="button" onMouseMove={move} onMouseLeave={() => setT('')} onClick={onOpen}
      className={['es-tile', 'es-tilt', category === 'infra' ? 'es-tile-infra' : '', className].filter(Boolean).join(' ')}
      style={{ transform: t || undefined, ...vars }}
    >
      <span className="es-tile-spot" />
      <span className="es-tile-shine" />
      <span className="es-tile-particle" style={{ left: '22%', animationDelay: '0s' }} />
      <span className="es-tile-particle" style={{ left: '64%', animationDelay: '1.1s' }} />
      <span className="es-tile-particle" style={{ left: '86%', animationDelay: '2.3s' }} />
      <span className="es-tile-head">
        <span className="es-tile-icon"><Icon name={icon} size={15} /></span>
        <StatusDot state={state} pulse={state === 'active'} />
      </span>
      <span>
        <span className="es-tile-title" style={{ display: 'block' }}>{title}</span>
        {meta ? <span className="es-caption" style={{ display: 'block', marginTop: 2 }}>{meta}</span> : null}
      </span>
      {preview.length ? (
        <span className="es-tile-preview">
          {preview.map((p, i) => (
            <span className={['es-tile-row', p.state ? 'es-tile-row-' + p.state : ''].filter(Boolean).join(' ')} key={i}>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.label}</span>
              <span className="es-num" style={{ fontSize: 'var(--text-xs)' }}>{p.value}</span>
            </span>
          ))}
        </span>
      ) : null}
    </button>
  );
}

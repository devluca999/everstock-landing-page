# DataValue

Any price, quantity, identifier or lead time. Monospace with tabular figures, non-negotiable.

~~~jsx
<DataValue label="Unit price" prefix="$" value="184.50" size="lg" />
<DataValue label="Lead time" value="6" unit="days" />
<DataValue label="Landed" prefix="$" value="18,240" delta={-4.2} align="right" />
~~~

delta is a percentage: negative renders success-green (cost went down), positive renders alert-red. Sizes md, lg, xl.

# MicroLabel

Small uppercase field label — the only uppercase role in the entire system.

~~~jsx
<MicroLabel>Unit price</MicroLabel>
<MicroLabel>Lead time</MicroLabel>
~~~

Never uppercase a heading, button or badge. Keep to one or two words.

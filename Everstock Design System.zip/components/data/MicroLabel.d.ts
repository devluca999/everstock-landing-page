import type { ReactNode } from 'react';
export interface MicroLabelProps {
  as?: keyof JSX.IntrinsicElements;
  className?: string;
  children?: ReactNode;
}
export declare function MicroLabel(props: MicroLabelProps): JSX.Element;

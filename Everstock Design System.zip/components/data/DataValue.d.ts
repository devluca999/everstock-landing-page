import type { ReactNode } from 'react';
import type { EverstockState } from '../feedback/StatusDot';
/**
 * Monospace, tabular-figure numeric display.
 */
export interface DataValueProps {
  label?: string;
  value: ReactNode;
  /** e.g. "ea", "days", "USD". */
  unit?: string;
  /** e.g. "$". */
  prefix?: string;
  size?: 'md' | 'lg' | 'xl';
  state?: EverstockState;
  align?: 'left' | 'right';
  /** Percentage change; negative renders success-green, positive renders alert-red. */
  delta?: number;
  className?: string;
}
export declare function DataValue(props: DataValueProps): JSX.Element;

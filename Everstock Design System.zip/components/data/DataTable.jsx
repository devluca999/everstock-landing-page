import React from 'react';

/**
 * Dense review table. Deliberately calm — no motion, no glass, no glow.
 * columns: {key,label,numeric,width,render}. Numeric columns right-align and go monospace.
 */
export function DataTable({ columns = [], rows = [], selectedId, onSelect, rowKey = 'id', className = '' }) {
  return (
    <table className={['es-table', className].filter(Boolean).join(' ')}>
      <thead>
        <tr>
          {columns.map(c => (
            <th key={c.key} className={c.numeric ? 'es-th-num' : undefined} style={c.width ? { width: c.width } : undefined}>
              {c.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={r[rowKey] ?? i}
            aria-selected={selectedId != null && r[rowKey] === selectedId ? 'true' : undefined}
            onClick={onSelect ? () => onSelect(r) : undefined}
            style={onSelect ? { cursor: 'pointer' } : undefined}>
            {columns.map(c => (
              <td key={c.key} className={c.numeric ? 'es-td-num' : undefined}>
                {c.render ? c.render(r) : r[c.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

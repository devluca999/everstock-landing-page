import React from 'react';
import { MicroLabel } from './MicroLabel.jsx';

/** Any price, quantity, identifier or lead time. Always monospace + tabular figures. */
export function DataValue({
  label, value, unit, prefix, size = 'md', state, align = 'left', delta, className = ''
}) {
  const cls = ['es-num', size === 'lg' ? 'es-num-lg' : size === 'xl' ? 'es-num-xl' : '', className].filter(Boolean).join(' ');
  const deltaColor = delta == null ? null : delta < 0 ? 'var(--state-success)' : 'var(--state-alert)';
  return (
    <span style={{ display: 'inline-flex', flexDirection: 'column', gap: 3, alignItems: align === 'right' ? 'flex-end' : 'flex-start' }}>
      {label ? <MicroLabel>{label}</MicroLabel> : null}
      <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 4 }}>
        <span className={cls} style={state ? { color: `var(--state-${state})` } : undefined}>
          {prefix}{value}
        </span>
        {unit ? <span className="es-num es-num-muted" style={{ fontSize: 'var(--text-2xs)' }}>{unit}</span> : null}
        {delta != null ? (
          <span className="es-num" style={{ fontSize: 'var(--text-2xs)', color: deltaColor }}>
            {delta > 0 ? '+' : ''}{delta}%
          </span>
        ) : null}
      </span>
    </span>
  );
}

# DataTable

Dense, fast, scannable review table. Deliberately calm — no glass, no glow, no motion.

~~~jsx
<DataTable rowKey="id" columns={[{key:"vendor",label:"Vendor"},{key:"unit",label:"Unit price",numeric:true},{key:"lead",label:"Lead time",numeric:true}]} rows={rows} onSelect={setRow} />
~~~

Set numeric on every column of figures — it right-aligns and switches to tabular monospace so digits stack. Use a StatusDot inside a render function for live rows; that is the only presence allowed here.

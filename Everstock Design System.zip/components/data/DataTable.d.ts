import type { ReactNode } from 'react';
export interface DataColumn<Row = any> {
  key: string;
  label: string;
  /** Right-aligns and applies monospace tabular figures. */
  numeric?: boolean;
  width?: number | string;
  render?: (row: Row) => ReactNode;
}
export interface DataTableProps<Row = any> {
  columns: DataColumn<Row>[];
  rows: Row[];
  selectedId?: string | number;
  onSelect?: (row: Row) => void;
  /** Field used as the React key and selection identity. Defaults to "id". */
  rowKey?: string;
  className?: string;
}
export declare function DataTable(props: DataTableProps): JSX.Element;

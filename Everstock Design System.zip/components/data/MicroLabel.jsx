import React from 'react';

/** Small uppercase field label — the system's only uppercase role. */
export function MicroLabel({ as = 'span', className = '', children, ...rest }) {
  const Tag = as;
  return <Tag className={['es-micro', className].filter(Boolean).join(' ')} {...rest}>{children}</Tag>;
}

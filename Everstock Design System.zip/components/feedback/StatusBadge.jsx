import React from 'react';
import { StatusDot } from './StatusDot.jsx';

/** State pill. Hue means state, never category — do not use this to label a task type. */
export function StatusBadge({ state = 'idle', dot = true, pulse = false, className = '', children }) {
  return (
    <span className={['es-badge', `es-badge-${state}`, className].filter(Boolean).join(' ')}>
      {dot ? <StatusDot state={state} pulse={pulse} /> : null}
      {children}
    </span>
  );
}

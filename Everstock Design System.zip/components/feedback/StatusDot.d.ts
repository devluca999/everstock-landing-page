export type EverstockState = 'active' | 'attention' | 'success' | 'alert' | 'idle';
export interface StatusDotProps {
  state?: EverstockState;
  /** Ambient breathing halo. Drops out under reduced motion. */
  pulse?: boolean;
  /** Optional text rendered next to the dot. */
  label?: string;
  className?: string;
}
export declare function StatusDot(props: StatusDotProps): JSX.Element;

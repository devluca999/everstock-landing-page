# StatusBadge

State pill for rows, headers and stage modules.

~~~jsx
<StatusBadge state="active" pulse>Live</StatusBadge>
<StatusBadge state="attention">Needs you</StatusBadge>
<StatusBadge state="success">Resolved</StatusBadge>
~~~

In dark mode these are washed tints with a coloured edge; in light mode they flip to saturated fills with white text so they hold up against the eggshell field. Never use a badge to label a category.

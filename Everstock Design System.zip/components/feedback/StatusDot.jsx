import React from 'react';

/** Ambient state indicator — the only presence garnish allowed on calm review surfaces. */
export function StatusDot({ state = 'idle', pulse = false, label, className = '' }) {
  const dot = (
    <span
      className={['es-dot', `es-dot-${state}`, pulse ? 'es-dot-pulse' : '', className].filter(Boolean).join(' ')}
      role={label ? 'img' : undefined}
      aria-label={label}
    />
  );
  if (!label) return dot;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-4)', color: 'var(--text-muted)', fontSize: 'var(--text-xs)' }}>
      {dot}{label}
    </span>
  );
}

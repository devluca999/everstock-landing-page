import type { ReactNode } from 'react';
export interface TooltipProps {
  content: ReactNode;
  placement?: 'top' | 'bottom' | 'left' | 'right';
  children?: ReactNode;
  className?: string;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;

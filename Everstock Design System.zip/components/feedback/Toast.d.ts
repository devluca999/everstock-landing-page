import type { ReactNode } from 'react';
import type { EverstockState } from './StatusDot';
export interface ToastProps {
  state?: EverstockState;
  title: string;
  description?: string;
  action?: ReactNode;
  onClose?: () => void;
  className?: string;
}
export declare function Toast(props: ToastProps): JSX.Element;

# Toast

Transient notice, stacked bottom-right above the floating input.

~~~jsx
<Toast state="success" title="PO-2291 issued" description="Meridian Supply confirmed in 40 seconds." onClose={dismiss} />
~~~

The state colour appears only on the left rail; the surface itself stays glass.

import type { ReactNode } from 'react';
import type { EverstockState } from './StatusDot';
/**
 * State pill. Hue is state only, never category.
 */
export interface StatusBadgeProps {
  state?: EverstockState;
  dot?: boolean;
  pulse?: boolean;
  className?: string;
  children?: ReactNode;
}
export declare function StatusBadge(props: StatusBadgeProps): JSX.Element;

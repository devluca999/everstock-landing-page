import React from 'react';

/** Hover/focus tooltip on a glass surface. Keep to one short line. */
export function Tooltip({ content, placement = 'top', children, className = '' }) {
  const [open, setOpen] = React.useState(false);
  return (
    <span
      className={['es-tooltip-wrap', className].filter(Boolean).join(' ')}
      onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}
    >
      {children}
      {open ? <span className={`es-tooltip es-tooltip-${placement}`} role="tooltip">{content}</span> : null}
    </span>
  );
}

import React from 'react';
import { Surface } from '../surfaces/Surface.jsx';
import { IconButton } from '../core/IconButton.jsx';

/** Transient notice. The left rail carries the state colour; the surface stays glass. */
export function Toast({ state = 'active', title, description, action, onClose, className = '' }) {
  return (
    <Surface material="glass" z={2} className={['es-toast', className].filter(Boolean).join(' ')}>
      <span className="es-toast-rail" style={{ background: `var(--state-${state})` }} />
      <div className="es-toast-body">
        <p className="es-toast-title">{title}</p>
        {description ? <p className="es-toast-desc">{description}</p> : null}
        {action ? <div style={{ marginTop: 'var(--space-5)' }}>{action}</div> : null}
      </div>
      {onClose ? <IconButton icon="x" label="Dismiss" size="sm" onClick={onClose} /> : null}
    </Surface>
  );
}

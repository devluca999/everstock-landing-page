# Tooltip

One short line of clarification on hover or focus.

~~~jsx
<Tooltip content="Landed cost including freight"><Icon name="circle-alert" /></Tooltip>
~~~

Never put an action inside a tooltip. Placement: top, bottom, left, right.

# StatusDot

The one ambient presence garnish allowed on calm review surfaces — a live-status dot in a table row or list header.

~~~jsx
<StatusDot state="active" pulse label="Sourcing" />
<StatusDot state="success" />
~~~

States: active (blue), attention (amber), success (green), alert (red), idle (neutral). pulse disables itself under reduced motion.

# Dialog

Z-2 modal on a blurred scrim — the strongest shadow and grain tier in the system.

~~~jsx
<Dialog title="Issue purchase order?" description="PO-2291 to Meridian Supply — this cannot be undone." onClose={close}
  footer={<><Button variant="ghost" onClick={close}>Cancel</Button><Button variant="primary">Issue PO</Button></>} />
~~~

Glass by default. Use material="chrome" only when the dialog reports something already committed.

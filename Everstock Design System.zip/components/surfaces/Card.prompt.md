# Card

Titled panel built on Surface, for review and lookup screens.

~~~jsx
<Card title="Open RFQs" subtitle="14 vendors responding" actions={<Button size="sm" variant="ghost">View all</Button>}>
  <DataTable columns={cols} rows={rows} />
</Card>
~~~

Defaults to material="panel" because most Cards live on calm surfaces. Use dense for tighter padding inside dashboards.

import React from 'react';

/**
 * The material primitive. Everything raised in Everstock is a Surface.
 * material: 'panel' (calm/dense) | 'glass' (active, ephemeral) | 'chrome' (resolved, committed).
 */
export function Surface({
  material = 'panel', z = 1, state, padded = false, as = 'div',
  className = '', children, ...rest
}) {
  const Tag = as;
  const cls = [
    'es-surface',
    material === 'glass' ? 'es-glass' : material === 'chrome' ? 'es-chrome' : '',
    `es-z${z}`,
    state ? `es-state-${state}` : '', className
  ].filter(Boolean).join(' ');
  return (
    <Tag className={cls} style={padded ? { padding: 'var(--pad-panel)' } : undefined} {...rest}>
      {children}
    </Tag>
  );
}

import React from 'react';
import { Surface } from './Surface.jsx';

/** Titled panel built on Surface. Use material="panel" on review/lookup screens. */
export function Card({
  title, subtitle, actions, footer, material = 'panel', z = 1, state,
  dense = false, className = '', children, ...rest
}) {
  const pad = dense ? 'var(--pad-panel)' : 'var(--pad-panel-lg)';
  return (
    <Surface material={material} z={z} state={state} className={className} {...rest}>
      {(title || actions) ? (
        <header style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          gap: 'var(--space-6)', padding: pad, paddingBottom: children ? 'var(--space-5)' : pad
        }}>
          <div>
            {title ? <h3 className="es-subtitle">{title}</h3> : null}
            {subtitle ? <p className="es-caption" style={{ marginTop: 2 }}>{subtitle}</p> : null}
          </div>
          {actions ? <div style={{ display: 'flex', gap: 'var(--gap-inline)', flex: 'none' }}>{actions}</div> : null}
        </header>
      ) : null}
      {children ? (
        <div style={{ padding: pad, paddingTop: (title || actions) ? 0 : pad }}>{children}</div>
      ) : null}
      {footer ? (
        <>
          <hr className="es-rule" />
          <div style={{ padding: pad, display: 'flex', alignItems: 'center', gap: 'var(--gap-inline)' }}>{footer}</div>
        </>
      ) : null}
    </Surface>
  );
}

import type { ReactNode } from 'react';
export interface DialogProps {
  open?: boolean;
  title?: string;
  description?: string;
  onClose?: () => void;
  footer?: ReactNode;
  /** chrome only when confirming something already committed. */
  material?: 'glass' | 'chrome' | 'panel';
  /** Selects the identity mark asset — must track the active theme. */
  theme?: 'dark' | 'light';
  children?: ReactNode;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;

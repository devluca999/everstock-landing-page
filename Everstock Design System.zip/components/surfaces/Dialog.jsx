import React from 'react';
import { Surface } from './Surface.jsx';
import { IconButton } from '../core/IconButton.jsx';
import { Identity } from '../brand/Identity.jsx';

/** Z-2 modal. Glass by default; use material="chrome" only to confirm something already committed. */
export function Dialog({ open = true, title, description, onClose, footer, material = 'glass', theme = 'dark', children }) {
  if (!open) return null;
  return (
    <div className="es-scrim" role="dialog" aria-modal="true" aria-label={title}>
      <Surface material={material} z={3} className="es-dialog">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-6)', marginBottom: 'var(--space-6)' }}>
          <Identity theme={theme} size="sm" />
          {onClose ? <IconButton icon="x" label="Close" onClick={onClose} /> : null}
        </div>
        <div className="es-dialog-head">
          <div>
            {title ? <h2 className="es-title" style={{ fontSize: 'var(--text-lg)' }}>{title}</h2> : null}
            {description ? <p className="es-body" style={{ marginTop: 6 }}>{description}</p> : null}
          </div>
        </div>
        {children}
        {footer ? <div className="es-dialog-foot">{footer}</div> : null}
      </Surface>
    </div>
  );
}

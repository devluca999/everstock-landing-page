import type { ReactNode, HTMLAttributes } from 'react';
export interface CardProps extends HTMLAttributes<HTMLElement> {
  title?: ReactNode;
  subtitle?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  material?: 'panel' | 'glass' | 'chrome';
  z?: 0 | 1 | 2 | 3;
  state?: 'active' | 'attention' | 'success' | 'alert';
  /** Tighter padding for dense review layouts. */
  dense?: boolean;
  children?: ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;

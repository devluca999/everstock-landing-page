import type { ReactNode, HTMLAttributes } from 'react';
/**
 * The material primitive every raised element is built on.
 */
export interface SurfaceProps extends HTMLAttributes<HTMLElement> {
  /** glass = active/ephemeral · chrome = resolved/committed · panel = calm review surfaces. */
  material?: 'panel' | 'glass' | 'chrome';
  /** Z-tier: 0 background · 1 mid · 2 foreground · 3 modal. Drives shadow, grain and blur strength. */
  z?: 0 | 1 | 2 | 3;
  /** Adds the state-coloured edge + glow on top of the dual-stack shadow. */
  state?: 'active' | 'attention' | 'success' | 'alert';
  padded?: boolean;
  as?: keyof JSX.IntrinsicElements;
  children?: ReactNode;
}
export declare function Surface(props: SurfaceProps): JSX.Element;

# Surface

The material primitive — every raised element in Everstock is a Surface, so you get grain, matte, sheen and the dual-stack shadow for free.

~~~jsx
<Surface material="glass" z={2} state="active" padded>Comparing 14 vendor quotes</Surface>
<Surface material="chrome" z={1} padded>PO-2291 issued</Surface>
<Surface material="panel" padded>Invoice history</Surface>
~~~

material: glass (active/ephemeral) · chrome (resolved/committed, dark mode only) · panel (calm review surfaces). Never write a bare div with a single box-shadow — that is the one construction this system forbids.
